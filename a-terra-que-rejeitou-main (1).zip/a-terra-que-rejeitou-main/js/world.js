'use strict';
// Mundo: estado do jogo, formas do espírito, física, jogador, inimigos, projéteis, perigos e desenho.

const G = {
  state: 'intro', save: newSave(), lvl: null, P: null, ents: [], projs: [], parts: [], hazards: [], boss: null,
  cam: { x: 0, y: -DY, shake: 0 }, t: 0, rt: 0, freeze: false, lock: 0, auto: 0, hitstop: 0, heat: 0, heatMul: 1,
  dynShade: [], waits: [], interact: null, flash: 0, flashCol: '#fff', dark: 0, sceneDraw: null, rain: 0, flags: {}, speedMul: 1, camTarget: null, fx: [], bfx: [],
};

// Dificuldade: monstros e chefes 50% mais duros que a base anterior (dano e vida ×1,5; chefes um pouco mais rápidos)
const DIFF = { dmg: 1.73, enemyHp: 1.8, bossHp: 1.8, bossSpeed: 1.25 };

// ---------- Formas (cada povo ensina um jeito de lutar) ----------
const FORMS = {
  espirito: { nome: 'Espírito sem forma', atk: { type: 'melee', dur: 0.34, act: [0.08, 0.18], range: 17, h: 22, dmg: 10, st: 10 }, shot: { dmg: 6, spd: 220, kind: 'orb' }, sp: null, dash: { dur: 0.34, spd: 170 } },
  zarabatana: { nome: 'Caçador da zarabatana', povo: 'Amazônia', atk: { type: 'melee', dur: 0.3, act: [0.07, 0.16], range: 20, h: 22, dmg: 11, st: 9 }, shot: { dmg: 10, spd: 320, kind: 'dart', st: 7 }, sp: { type: 'burst', dur: 0.5, st: 45, cd: 1.2, dmg: 6 }, dash: { dur: 0.42, spd: 215 } },
  arco: { nome: 'Arqueira do cerrado', povo: 'Cerrado', atk: { type: 'combo', st: 11, hits: [{ dur: 0.3, act: [0.07, 0.16], range: 22, h: 22, dmg: 12 }, { dur: 0.3, act: [0.07, 0.16], range: 22, h: 22, dmg: 12 }, { dur: 0.46, act: [0.14, 0.26], range: 26, h: 24, dmg: 20 }] }, shot: { dmg: 11, spd: 330, kind: 'arrow' }, sp: { type: 'firearrow', dur: 0.5, st: 45, cd: 1.3, dmg: 14 }, dash: { dur: 0.34, spd: 185 }, track: true },
  lanca: { nome: 'Canoeiro das águas', povo: 'Pantanal', atk: { type: 'melee', dur: 0.42, act: [0.12, 0.24], range: 34, h: 14, dmg: 17, st: 13 }, shot: { dmg: 9, spd: 260, kind: 'javelin', grav: 60 }, sp: { type: 'throw', dur: 0.45, st: 45, cd: 1.2, dmg: 24 }, dash: { dur: 0.34, spd: 180 }, water: true },
  cabaca: { nome: 'Lanceira da cabaça', povo: 'Caatinga', atk: { type: 'melee', dur: 0.38, act: [0.1, 0.22], range: 28, h: 20, dmg: 16, st: 12 }, shot: { dmg: 9, spd: 250, kind: 'drop', grav: 120 }, sp: { type: 'splash', dur: 0.5, st: 42, cd: 1.4, dmg: 16 }, dash: { dur: 0.34, spd: 180 }, heatRes: 0.7 },
  semente: { nome: 'Anciã das sementes', povo: 'Mata Atlântica', atk: { type: 'melee', dur: 0.36, act: [0.1, 0.22], range: 24, h: 22, dmg: 17, st: 11 }, shot: { dmg: 10, spd: 280, kind: 'seed' }, sp: { type: 'roots', dur: 0.5, st: 48, cd: 1.4, dmg: 28 }, dash: { dur: 0.36, spd: 190 } },
};
const FORM_ORDER = ['zarabatana', 'arco', 'lanca', 'cabaca', 'semente'];

// ---------- Construtor de fases ----------
function LV(o) {
  const L = Object.assign({ solids: [], water: [], shade: [], grass: [], spawns: [], npcs: [], fires: [], props: [], triggers: [], decor: [], ramps: [], vines: [], canopies: [], thorns: [], stumps: [], chests: [], areas: [], dthorns: [], hvines: [], gates: [], murals: [], doors: [], bridges: [], lights: [] }, o);
  L.g = (x0, x1, y = GY) => (L.solids.push({ x: x0, y, w: x1 - x0, h: 240 - y, t: 'g' }), L);
  L.b = (x, y, w, h) => (L.solids.push({ x, y, w, h, t: 'g', block: true }), L);
  L.p = (x, y, w, move) => (L.solids.push({ x, y, w, h: 4, t: 'p', ox: x, oy: y, move, mdx: 0, mdy: 0 }), L);
  // peças do tileset: galho, ilha, tronco-rampa, cipó escalável, copa, espinhos e toco
  L.br = (x, y, w) => (L.solids.push({ x, y, w, h: 4, t: 'p', kind: 'branch' }), L);
  L.flog = (x, y, w) => (L.solids.push({ x, y, w, h: 4, t: 'p', kind: 'flog', ox: x, oy: y, move: { dx: 0, dy: 1.5, spd: 1.6 }, mdx: 0, mdy: 0 }), L);
  L.isl = (x, y) => (L.solids.push({ x, y, w: 26, h: 4, t: 'p', kind: 'island' }), L);
  L.ramp = (x0, y0, x1, y1) => (L.ramps.push({ x0, y0, x1, y1 }), L);
  L.vine = (x, y0, y1 = GY) => (L.vines.push({ x, y0, y1 }), L);
  L.can = (x, w, vines) => (L.canopies.push({ x, w, vines }), L);
  L.th = (x0, x1, y = GY) => (L.thorns.push({ x0, x1, y }), L);
  L.stump = x => (L.stumps.push({ x, y: GY }), L.solids.push({ x: x - 12, y: GY - 30, w: 24, h: 30, t: 'g', block: true, vis: 'none' }), L);
  // elementos interativos: baú, tronco cortado, marca de área, planta sombria e cipós pendentes
  L.chest = (x, id, y = GY) => (L.chests.push({ x, y, id }), L);
  L.log = x => (L.solids.push({ x: x - 15, y: GY - 18, w: 30, h: 18, t: 'g', block: true, vis: 'log' }), L);
  L.area = x => (L.areas.push({ x }), L);
  L.dthorn = x => (L.dthorns.push({ x }), L);
  L.hv = x => (L.hvines.push({ x }), L);
  L.wt = (x0, x1, y = 152) => (L.water.push({ x: x0, y, w: x1 - x0, h: 240 - y }), L);
  L.sh = (x0, x1, kind = 'rock') => (L.shade.push({ x: x0, w: x1 - x0, kind }), L);
  L.gr = (x0, x1) => (L.grass.push({ x: x0, w: x1 - x0 }), L);
  L.e = (type, x, y) => (L.spawns.push({ type, x, y }), L);
  L.n = o2 => (L.npcs.push(Object.assign({ f: 1, anim: 'idle' }, o2)), L);
  L.f = (x, id) => (L.fires.push({ x, id }), L);
  L.echo = (x, y, id) => (L.echoAt = { x, y, id }, L);
  L.pr = (kind, x, y, o2) => (L.props.push(Object.assign({ kind, x, y }, o2 || {})), L);
  L.tr = (x, fn) => (L.triggers.push({ x, fn, done: false }), L);
  L.ar = (x0, boss) => (L.arena = { x0, boss, active: false }, L);
  // Gruta dos Antigos e revisitas: Cipós-de-Sangue (selo), pintura rupestre, porta, ponte de atalho e luz fixa
  L.gate = (x, id, o2) => (L.gates.push(Object.assign({ x, id, y: GY, w: 18, h: 56, solid: true, kind: 'parede' }, o2 || {})), L);
  L.mural = (x, id, o2) => (L.murals.push(Object.assign({ x, id, y: GY - 66, w: 60, h: 40, lit: 0 }, o2 || {})), L);
  L.door = (x, to, toX, label, o2) => (L.doors.push(Object.assign({ x, to, toX, label }, o2 || {})), L);
  L.bridge = (x0, x1, y, id, lx) => (L.bridges.push({ x0, x1, y, id, lx }), L);
  L.light = (x, y, r) => (L.lights.push({ x, y, r }), L);
  return L;
}
function groundY(x, from = -50) {
  let best = 999;
  for (const s of G.lvl.solids) if (x >= s.x && x <= s.x + s.w && s.y >= from && s.y < best && !s.wall) best = s.y;
  return best;
}
function solidAt(x, y) { for (const s of G.lvl.solids) if (x >= s.x && x < s.x + s.w && y >= s.y && y < s.y + s.h) return s; return null; }

// copas e cipós extras pelo céu: preenchem os trechos sem copa, deixando a arena livre
function addSkyCanopies(L) {
  const r = seeded(L.w * 13 + L.id.length * 7), A = L.arena;
  for (let x = 60; x < L.w - 50; x += 85 + r() * 70) {
    if (A && x > A.x0 - 40 && x < A.x0 + AW + 40) continue;
    if (L.canopies.some(c => Math.abs(c.x + c.w / 2 - x) < 70)) continue;
    const w = 50 + 10 * (r() * 5 | 0);
    L.canopies.push({ x: Math.round(x - w / 2), w, vines: 2 + (r() * 3 | 0), y: r() * 26 | 0 });
    if (r() < 0.35) L.hvines.push({ x: Math.round(x + (r() - 0.5) * 50) });
  }
}
// cada árvore precisa de chão firme embaixo: procura um ponto de chão sob a copa (nunca buraco nem água);
// sem chão, a copa sai. O tronco engrossa com o tamanho da copa.
function treeGround(L, x) {
  if (L.water.some(w => x > w.x - 6 && x < w.x + w.w + 6)) return null;
  let best = 999; for (const s of L.solids) if (s.t === 'g' && !s.wall && x >= s.x + 3 && x <= s.x + s.w - 3 && s.y < best) best = s.y;
  return best <= 170 ? best : null;
}
function prepareTrees(L) {
  L.canopies = L.canopies.filter(cn => {
    const c = cn.x + cn.w / 2;
    for (const k of [0, -0.15, 0.15, -0.3, 0.3, -0.42, 0.42]) { const x = Math.round(c + k * cn.w); if (treeGround(L, x) != null) { cn.tx = x; cn.tw = clamp(Math.round(cn.w * 0.17), 8, 14); return true; } }
    return false;
  });
  L.hvines = L.hvines.filter(o => { for (const dx of [0, -8, 8, -16, 16]) if (treeGround(L, o.x + dx) != null) { o.tx = o.x + dx; return true; } return false; });
}
function loadLevel(id) {
  const L = LEVELS[id]();
  L.id = id;
  if (typeof configureJourney === 'function') configureJourney(L);
  const AR = L.arena;
  if (AR && AR.x0 + AW > L.w) {
    const old = L.w; L.w = AR.x0 + AW;
    for (const s of L.solids) if (s.t === 'g' && !s.block && s.x + s.w >= old - 1) s.w += L.w - old;
    for (const w of L.water) if (w.x + w.w >= old - 1) w.w += L.w - old;
  }
  L.solids.push({ x: -20, y: -200, w: 20, h: 500, t: 'g', wall: true }, { x: L.w, y: -200, w: 20, h: 500, t: 'g', wall: true });
  applyWorldState(L);
  if (!L.cave) { addSkyCanopies(L); prepareTrees(L); }
  if (typeof finishJourneyScenery === 'function') finishJourneyScenery(L);
  // tufos de grama decorativos
  const r = seeded(id.length * 97 + 3);
  for (const s of L.solids) if (s.t === 'g' && !s.wall && !s.block) for (let x = s.x + 2; x < s.x + s.w - 2; x += 3 + r() * 9 | 0) L.decor.push({ x, y: s.y, h: 1 + r() * 4 | 0, c: r() });
  G.lvl = L; G.fx = []; G.bfx = []; G.projs = []; G.parts = []; G.hazards = []; G.boss = null; G.dynShade = []; G.heat = 0; G.heatMul = 1; G.dark = 0;
  for (const n of L.npcs) n.t = rnd(0, 5);
  spawnEnemies();
  musicSet(L.biome === 'mata' ? 'mata' : L.biome);
}

// ---------- Jogador ----------
function statMax() { const s = G.save; return { hp: 100 + s.vig * 15 + itemBonus('hp'), st: 100 + s.fol * 12 + itemBonus('st'), flasks: Math.min(9, 3 + Math.floor(s.act / 2) + (s.bonusFlask || 0) + itemBonus('flask')) }; }
function makePlayer(x, y) {
  const m = statMax();
  return { hpMax: () => statMax().hp, stMax: () => statMax().st, form: 'espirito', x, y: y - 22, w: 10, h: 22, vx: 0, vy: 0, f: 1, onG: false, coy: 0, jbuf: 0, hp: m.hp, st: m.st, stDelay: 0, inv: 0, state: 'normal', stT: 0, combo: 0, queued: false, hitSet: null, def: null, spCd: 0, flasks: m.flasks, ph: 0, airDash: true, drop: 0, plat: null, safe: { x, y: y - 22 }, inWater: false, slow: 0, stun: 0, ab: { jump: true, attack: true, dodge: true, special: true, heal: true } };
}
const GRAV = 900, JUMP = 292;
function dmgMul() { return (1 + 0.1 * G.save.forc + 0.08 * G.save.frag + itemBonus('dmg')); }
// cada ato pesa mais: golpes, esquivas e especiais gastam 10% a mais de energia por ato
function useSt(n) { const P = G.P; P.st -= n * (1 + 0.1 * ((G.lvl && G.lvl.act) || 0)); P.stDelay = 0.45; }

function updatePlayer(dt) {
  const P = G.P, F = FORMS[P.form] || FORMS.espirito;
  const ctl = G.lock === 0 && P.state !== 'dead';
  let mx = ctl ? (I.down.right ? 1 : 0) - (I.down.left ? 1 : 0) : 0;
  if (G.auto) mx = G.auto;
  if (P.stun > 0) { P.stun -= dt; mx = 0; }
  P.inv -= dt; P.stDelay -= dt; P.spCd -= dt; P.jbuf -= dt; P.drop -= dt; P.slow -= dt;
  const hot = G.heat >= 100;
  if (P.stDelay <= 0 && P.state !== 'dash' && P.state !== 'attack') P.st = Math.min(P.stMax(), P.st + (hot ? 22 : 48) * dt);
  const water = P.inWater && !F.water, wform = P.inWater && F.water;
  let spd = 88 * (1 + itemBonus('speed')) * (water ? 0.55 : wform ? 1.12 : 1) * (P.slow > 0 ? 0.55 : 1) * (G.speedMul || 1) * (G.lvl.cave && I.down.down && P.onG ? 0.45 : 1);
  const press = a => ctl && P.stun <= 0 && I.pressed[a];
  const vine = P.state === 'normal' && nearVine(P);
  if (vine && press('up') && P.ab.jump) grabVine(vine);
  if (P.state === 'normal') {
    P.vx = lerp(P.vx, mx * spd, P.onG ? 0.35 : 0.18);
    if (mx) P.f = mx;
    if (press('jump')) P.jbuf = 0.13;
    if (P.jbuf > 0 && (P.onG || P.coy > 0) && P.ab.jump) {
      if (I.down.down && P.plat && P.plat.t === 'p') { P.drop = 0.25; P.jbuf = 0; }
      else { P.vy = -JUMP * (water ? 0.8 : wform ? 1.15 : 1); P.jbuf = 0; P.coy = 0; P.jumping = true; SFX.jump(); if (P.inWater) splash(P.x + 5, P.y + P.h); }
    }
    if (P.jumping && !I.down.jump && P.vy < -110) { P.vy = -110; P.jumping = false; }
    if (press('attack') && P.ab.attack && P.st > 0) startAttack();
    else if (press('shoot') && P.ab.attack && P.st > 0) startShot();
    else if (press('special') && P.ab.special && F.sp && P.spCd <= 0 && P.st > 4) startSpecial();
    else if (press('dodge') && P.ab.dodge && P.st > 0 && (P.onG || P.airDash)) startDash();
    else if (press('heal') && P.ab.heal && P.onG) { if (P.flasks > 0) { P.state = 'heal'; P.stT = 0; P.healed = false; } else floatText(P.x + 5, P.y - 4, 'cabaça vazia'); }
    else if (press('swap') && G.save.forms.length > 2 && G.lvl.biome === 'mata' && !G.flags.final) swapForm();
  } else if (P.state === 'attack' || P.state === 'special') {
    P.stT += dt;
    P.vx = lerp(P.vx, P.onG ? 0 : P.vx, 0.15);
    if (P.state === 'attack') attackTick(); else specialTick();
    if (press('attack') && P.state === 'attack' && P.stT > P.def.dur * 0.4) P.queued = true;
    if (P.stT >= P.def.dur) {
      P.state = 'normal';
      if (P.queued && F.atk.type === 'combo' && P.def.type !== 'shot' && P.combo < 2 && P.st > 0) { P.combo++; startAttack(true); }
      else P.combo = 0;
      P.queued = false;
    }
  } else if (P.state === 'dash') {
    P.stT += dt; const D = F.dash;
    P.vx = P.f * D.spd * (1 - P.stT / D.dur * 0.4) * (water ? 0.6 : 1);
    if (!P.onG) P.vy = Math.min(P.vy, 30);
    if (P.stT >= D.dur) P.state = 'normal';
  } else if (P.state === 'heal') {
    P.stT += dt; P.vx = 0;
    if (!P.healed && P.stT > 0.45) { P.healed = true; P.flasks--; P.hp = Math.min(P.hpMax(), P.hp + 45 + G.save.vig * 4 + itemBonus('heal')); SFX.heal(); for (let i = 0; i < 10; i++) part(P.x + 5 + rnd(-6, 6), P.y + rnd(0, 20), rnd(-10, 10), rnd(-40, -10), 0.8, '#f2c14e'); }
    if (P.stT >= 0.7) P.state = 'normal';
  } else if (P.state === 'hurt') {
    P.stT += dt; P.vx = lerp(P.vx, 0, 0.1);
    if (P.stT >= 0.28) P.state = 'normal';
  } else if (P.state === 'climb') {
    // cipó: sobe e desce sem gravidade; direção + pulo solta, no topo sobe para o lado
    const v = P.vine, up = ctl && (I.down.up || I.down.jump), dn = ctl && I.down.down;
    P.vx = 0; P.x = v.x - 5; P.vy = ((dn ? 1 : 0) - (up ? 1 : 0)) * 58;
    if (mx) P.f = mx;
    if (mx && press('jump')) { P.state = 'normal'; P.vy = -JUMP * 0.85; P.vx = mx * 110; P.jumping = true; SFX.jump(); }
    else if (press('dodge')) P.state = 'normal';
    else if (up && P.y + P.h <= v.y0 + 2) { P.state = 'normal'; P.vy = -210; P.vx = (mx || P.f) * 70; }
    else if (dn && P.y + P.h >= v.y1) P.state = 'normal';
  } else if (P.state === 'dead') { P.vx = 0; P.deadT = (P.deadT || 0) + dt; }
  // física
  const wasG = P.onG;
  if (P.state === 'climb') {
    P.y = clamp(P.y + P.vy * dt, P.vine.y0 - P.h, P.vine.y1 - P.h); P.onG = false; P.plat = null;
    if (P.vy && Math.random() < 0.08) SFX.step();
  } else {
    const g = GRAV * (P.inWater ? 0.5 : 1) * (P.vy > 0 ? 1.15 : 1);
    P.vy = Math.min(P.vy + g * dt, P.inWater ? 120 : 420);
    if (P.plat && P.plat.mdx !== undefined && P.onG) { P.x += P.plat.mdx; P.y += P.plat.mdy; }
    moveBody(P, dt);
  }
  // espinhos: dano fixo, empurrão para trás e para cima (inimigos não sofrem)
  for (const th of G.lvl.thorns) if (P.state !== 'dead' && overlap(P, { x: th.x0 + 2, y: th.y - 10, w: th.x1 - th.x0 - 4, h: 10 })) hurtPlayer(THORN_DMG, (th.x0 + th.x1) / 2, { fixed: true });
  for (const d of G.lvl.dthorns) if (P.state !== 'dead' && overlap(P, { x: d.x - 7, y: GY - 16, w: 14, h: 16 })) hurtPlayer(THORN_DMG, d.x, { fixed: true });
  if (P.onG) { P.coy = 0.1; P.airDash = true; P.jumping = false; if (!wasG && P.vy >= 0) { SFX.land(); } } else P.coy -= dt;
  if (P.onG && P.plat && P.plat.t === 'g' && !P.plat.wall && P.state !== 'dash' && P.x >= P.plat.x + 6 && P.x + P.w <= P.plat.x + P.plat.w - 6) P.safe = { x: P.x, y: P.y };
  // água
  const wasW = P.inWater; P.inWater = false;
  for (const w of G.lvl.water) if (P.x + 5 > w.x && P.x + 5 < w.x + w.w && P.y + P.h > w.y + 3) P.inWater = true;
  if (P.inWater !== wasW && Math.abs(P.vy) > 40) splash(P.x + 5, (G.lvl.water[0] || {}).y || P.y + P.h);
  // queda em abismo
  if (P.y > (G.lvl.h || WORLD_H) + 40 && P.state !== 'dead') { P.x = P.safe.x; P.y = P.safe.y; P.vx = P.vy = 0; P.jbuf = 0; hurtPlayer(15, null, { pit: true }); }
  // passos e animação
  P.ph += Math.abs(P.vx) * dt * 0.22;
  if (P.onG && Math.abs(P.vx) > 30 && Math.sin(P.ph) * Math.sin(P.ph - Math.abs(P.vx) * dt * 0.22) < 0) SFX.step();
  // calor (Caatinga): 1 s no sol sem sombra e começa a queimar; no sol a pino queima mais rápido
  if (G.lvl.biome === 'caatinga' && P.state !== 'dead') {
    const sh = inShade(P.x + 5);
    if (sh) G.heat = Math.max(0, G.heat - 60 * dt);
    else G.heat = Math.min(100, G.heat + 100 * (F.heatRes || 1) * (1 - itemBonus('heat')) * dt * (G.lock ? 0 : 1));
    if (G.heat >= 100 && !G.lock) { P.burn = (P.burn || 0) - dt; if (P.burn <= 0) { P.burn = G.heatMul > 1 ? 0.3 : 0.5; P.hp -= 5; floatText(P.x + 5, P.y - 2, 'calor', '#ff8a5a'); if (P.hp <= 0) die(); } }
    else if (G.heat >= 75 && Math.random() < 0.08) part(P.x + 5 + rnd(-4, 4), P.y + rnd(0, 6), 0, rnd(-30, -10), 0.6, '#fff0c0');
    // sol a pino também fora da luta: de tempos em tempos a queimadura acelera por alguns segundos
    if (!G.boss) { G.sunCd = (G.sunCd == null ? 20 : G.sunCd) - dt; if (G.sunT > 0) { G.sunT -= dt; G.heatMul = 2; if (G.sunT <= 0) G.heatMul = 1; } else if (G.sunCd <= 0 && !G.lock) { G.sunCd = rnd(22, 34); G.sunT = 5; showToast('Sol a pino', 'procure a sombra', 1.6); } }
  }
  // afogamento: encostou na água, tem 0,5 s para sair antes de começar a perder vida (o canoeiro aguenta o dobro)
  if (P.inWater && P.state !== 'dead' && !G.lock) {
    P.breath = Math.max(0, (P.breath == null ? 100 : P.breath) - (F.water ? 100 : 200) * (1 - itemBonus('breath')) * dt);
    if (P.breath <= 0) { P.drown = (P.drown || 0) - dt; if (P.drown <= 0) { P.drown = 0.5; P.hp -= 6; floatText(P.x + 5, P.y - 2, 'afogando', '#9fd0e0'); SFX.splash(); if (P.hp <= 0) die(); } }
    if (Math.random() < 0.06) part(P.x + 5 + rnd(-3, 3), P.y + 4, 0, -25, 0.8, '#c8e8f8');
  } else { P.breath = Math.min(100, (P.breath == null ? 100 : P.breath) + 70 * dt); P.drown = 0; }
  // memórias deixadas na morte
  const d = G.save.drop;
  if (d && d.lvl === G.lvl.id && Math.abs(P.x + 5 - d.x) < 10 && Math.abs(P.y + 11 - d.y) < 22) { G.save.mem += d.mem; floatText(d.x, d.y - 10, '+' + d.mem + ' memórias'); SFX.echo(); G.save.drop = null; writeSave(); }
}
function inShade(x) {
  for (const s of G.lvl.shade) if (x > s.x && x < s.x + s.w) return true;
  for (const s of G.dynShade) if (x > s.x && x < s.x + s.w) return true;
  return false;
}
const THORN_DMG = 10;
const RAMP_PLAT = { t: 'p', ramp: true };
function nearVine(P) { for (const v of G.lvl.vines) if (Math.abs(P.x + 5 - v.x) < 8 && P.y + P.h > v.y0 + 4 && P.y < v.y1 - 4) return v; return null; }
function grabVine(v) { const P = G.P; Object.assign(P, { state: 'climb', vine: v, vx: 0, vy: 0, jbuf: 0, jumping: false }); if (P.h !== 22) { P.y -= 22 - P.h; P.h = 22; } }
function moveBody(b, dt) {
  const S = G.lvl.solids;
  b.hitWall = false;
  b.x += b.vx * dt;
  for (const s of S) if (s.t === 'g' && overlap(b, s)) {
    // bichos que andam sobem degraus baixos (terreno elevado, toco) em vez de bater na parede
    if (b.stepH && b.onG && !s.wall && s.y >= b.y + b.h - b.stepH) { b.y = s.y - b.h; continue; }
    if (b.x + b.w / 2 < s.x + s.w / 2) b.x = s.x - b.w; else b.x = s.x + s.w; b.hitWall = true; }
  const prevB = b.y + b.h;
  b.y += b.vy * dt; b.onG = false; b.plat = null;
  for (const s of S) {
    if (!overlap(b, s)) continue;
    if (s.t === 'g') {
      if (b.vy >= 0 && prevB <= s.y + 6) { b.y = s.y - b.h; b.vy = 0; b.onG = true; b.plat = s; }
      else if (b.vy < 0) { b.y = s.y + s.h; b.vy = 0; }
    } else if (s.t === 'p' && b.vy >= 0 && prevB <= s.y + 2 + Math.abs(s.mdy || 0) && !(b.drop > 0)) { b.y = s.y - b.h; b.vy = 0; b.onG = true; b.plat = s; }
  }
  // rampas (tronco caído): só o topo conta; quem já está nela acompanha a descida
  const wasRamp = b.onRamp; b.onRamp = false;
  if (!(b.drop > 0)) for (const r of G.lvl.ramps) {
    const cx = b.x + b.w / 2; if (cx < Math.min(r.x0, r.x1) || cx > Math.max(r.x0, r.x1)) continue;
    const ry = r.y0 + (r.y1 - r.y0) * (cx - r.x0) / (r.x1 - r.x0), foot = b.y + b.h, slack = wasRamp ? 6 : 0;
    if (b.vy >= 0 && foot >= ry - slack && prevB <= ry + 4 + slack && !(b.onG && b.y + b.h < ry)) { b.y = ry - b.h; b.vy = 0; b.onG = true; b.onRamp = true; b.plat = RAMP_PLAT; }
  }
}
// Equilíbrio: de perto bate mais forte e cansa menos; de longe bate mais fraco e cansa mais
const PERTO = { dmg: 1.3, st: 0.7 }, LONGE = { dmg: 0.75, st: 1.4 };
const SP_PERTO = { splash: true };
// De onde sai cada projétil: da ponta da arma na pose de disparo (x à frente do centro, y a partir do topo do corpo)
const SAIDA = { arrow: [12, 8], firearrow: [12, 7], dart: [19, 4], burst: [19, 4], javelin: [6, 2], throw: [6, 2], drop: [9, 9], seed: [3, -12], orb: [9, 8] };
function shotOrigin(P, kind) { const o = SAIDA[kind] || [8, 10], foot = P.y + P.h; return [P.x + 5 + P.f * o[0] * HUMAN_S, foot - (22 - o[1]) * HUMAN_S]; }
function startAttack(cont) {
  const P = G.P, F = FORMS[P.form] || FORMS.espirito, A = F.atk;
  if (!cont) P.combo = 0;
  faceMouse();
  P.def = A.type === 'combo' ? Object.assign({ type: 'melee' }, A.hits[P.combo]) : A;
  P.state = 'attack'; P.stT = 0; P.hitSet = new Set(); P.shot = false;
  useSt(A.st * PERTO.st); SFX.swing(P.form);
  if (P.onG) P.vx = P.f * 30;
  emitNoise(P.x + 5, P.y + 11, 70);
}
function startShot() {
  const P = G.P, F = FORMS[P.form] || FORMS.espirito;
  faceMouse();
  P.def = Object.assign({ type: 'shot', dur: 0.3, at: 0.08, st: 9 }, F.shot);
  P.state = 'attack'; P.stT = 0; P.combo = 0; P.shot = false;
  useSt(P.def.st * LONGE.st); SFX.dart();
}
// Clique do mouse vira o personagem para o lado do cursor
function faceMouse() { const P = G.P; if (performance.now() - I.mouseT < 150) P.f = Math.sign(I.mouseWX - (P.x + 5)) || P.f; }
// Mira automática: o alvo mais próximo à frente (inclusive voadores), num cone generoso
function aimAt(x, y, range) {
  const P = G.P, cands = [];
  for (const e of G.ents) if (e.hp > 0) cands.push([e.x + e.w / 2, e.y + e.h / 2]);
  const B = G.boss;
  if (B && !B.noAim && !(B.hidden && !(FORMS[P.form] || {}).track) && !['down', 'still', 'ask', 'intro'].includes(B.st)) cands.push([B.x, B.y - B.h * 0.55]);
  let best = null, bd = range; aimAt.d = 0;
  for (const [cx, cy] of cands) {
    const dx = (cx - x) * P.f, dy = cy - y;
    if (dx < 4 || dx > range || Math.abs(dy) > dx * 1.4 + 14) continue;
    const d = Math.hypot(dx, dy); if (d < bd) { bd = d; best = [cx, cy]; }
  }
  if (!best) return 0;
  aimAt.d = bd;
  return clamp(Math.atan2(best[1] - y, (best[0] - x) * P.f), -1.05, 1.05);
}
function attackTick() {
  const P = G.P, D = P.def;
  if (D.type === 'shot') {
    if (!P.shot && P.stT >= D.at) {
      P.shot = true;
      const [x, y] = shotOrigin(P, D.kind), a = aimAt(x, y, 200);
      const g = D.grav || 0, comp = aimAt.d ? g * (aimAt.d / D.spd) / 2 : 0;
      shoot({ x, y, vx: P.f * Math.cos(a) * D.spd, vy: Math.sin(a) * D.spd - comp, w: 9, h: 9, dmg: D.dmg * dmgMul() * LONGE.dmg, kind: D.kind, grav: D.grav || 0 });
    }
    return;
  }
  if (P.stT >= D.act[0] && P.stT <= D.act[1]) {
    const hb = { x: P.f > 0 ? P.x + P.w - 2 : P.x + 2 - D.range, y: P.y + 10 - D.h / 2, w: D.range, h: D.h };
    meleeHit(hb, D.dmg * dmgMul() * PERTO.dmg, P.hitSet, { melee: true });
    if (G.debug) G.lastHB = hb;
  }
}
function meleeHit(hb, dmg, set, o) {
  const P = G.P;
  let any = false;
  for (const e of G.ents) if (!set.has(e) && e.hp > 0 && overlap(hb, e)) { set.add(e); hitEnemy(e, dmg, P.f, o); any = true; }
  const B = G.boss;
  if (B && !set.has(B) && overlap(hb, bossBox(B))) { set.add(B); if (bossHurt(B, dmg, P.f)) any = true; }
  if (any) { G.hitstop = 0.045; }
  return any;
}
function startSpecial() {
  const P = G.P, F = FORMS[P.form];
  P.def = F.sp; P.state = 'special'; P.stT = 0; P.hitSet = new Set(); P.shots = 0;
  useSt(Math.min(P.st, F.sp.st * (SP_PERTO[F.sp.type] ? PERTO.st : LONGE.st))); P.spCd = F.sp.cd;
}
function specialTick() {
  const P = G.P, D = P.def, m = dmgMul() * (SP_PERTO[D.type] ? PERTO.dmg : LONGE.dmg), cx = P.x + 5, [ox, oy] = shotOrigin(P, D.type);
  if (D.type === 'burst') {
    while (P.shots < 3 && P.stT >= 0.08 + P.shots * 0.11) { P.shots++; SFX.dart(); shoot({ x: ox, y: oy, vx: P.f * 320, vy: (P.shots - 2) * 25, w: 6, h: 6, dmg: D.dmg * m, kind: 'dart', poison: true }); }
  } else if (D.type === 'firearrow') {
    if (!P.shots && P.stT >= 0.28) { P.shots = 1; SFX.fire(); shoot({ x: ox, y: oy, vx: P.f * 250, vy: -60, w: 8, h: 2, dmg: D.dmg * m, kind: 'fire', grav: 220 }); }
  } else if (D.type === 'throw') {
    if (!P.shots && P.stT >= 0.2) { P.shots = 1; SFX.swing(); shoot({ x: ox, y: oy, vx: P.f * 330, vy: -10, w: 18, h: 2, dmg: D.dmg * m, kind: 'spear', pierce: true, grav: 40 }); }
  } else if (D.type === 'splash') {
    if (!P.shots && P.stT >= 0.22) {
      P.shots = 1; SFX.splash(); G.heat = Math.max(0, G.heat - 45);
      const hb = { x: cx + (P.f > 0 ? -6 : -40), y: P.y - 8, w: 46, h: 34 };
      meleeHit(hb, D.dmg * m, P.hitSet, { cool: true, melee: true });
      for (let i = 0; i < 24; i++) part(cx + P.f * rnd(4, 36), P.y + rnd(0, 20), P.f * rnd(10, 60), rnd(-90, -20), 0.6, i % 2 ? '#9fd0e0' : '#e8f4f8', 1, 300);
    }
  } else if (D.type === 'roots') {
    if (!P.shots && P.stT >= 0.25) {
      P.shots = 1;
      let tx = cx + P.f * 50, best = 160;
      const cands = G.ents.filter(e => e.hp > 0).map(e => e.x + e.w / 2); if (G.boss) cands.push(G.boss.x);
      for (const x of cands) { const d = (x - cx) * P.f; if (d > 0 && d < best) { best = d; tx = x; } }
      addHazard({ kind: 'proots', x: tx - 12, y: groundY(tx, P.y) - 26, w: 24, h: 26, t: 0, life: 0.75, dmg: D.dmg * m, team: 'p', set: new Set() });
    }
  }
}
function startDash() {
  const P = G.P, F = FORMS[P.form] || FORMS.espirito;
  if (!P.onG) P.airDash = false;
  P.state = 'dash'; P.stT = 0; useSt(18);
  // Mesma janela da cambalhota, incluindo o bônus original da Pena de gavião.
  P.inv = Math.max(P.inv, F.dash.dur * (0.85 + itemBonus('roll')));
  P.vx = P.f * F.dash.spd * (P.inWater && !F.water ? 0.6 : 1); SFX.dash();
}
function swapForm() {
  const P = G.P, list = G.save.forms.filter(f => f !== 'espirito');
  const i = (list.indexOf(P.form) + 1) % list.length; setForm(list[i]);
  for (let k = 0; k < 14; k++) part(P.x + 5 + rnd(-8, 8), P.y + rnd(0, 22), rnd(-20, 20), rnd(-40, 0), 0.6, '#8fe37a');
  SFX.ui();
}
function setForm(f) { G.P.form = f; G.save.form = f; updateHudForm(); }

function hurtPlayer(dmg, srcX, o = {}) {
  const P = G.P;
  if (!P || P.state === 'dead') return false;
  if (!o.pit && (P.inv > 0 || G.lock > 0 && !o.force)) return false;
  if (!o.pit && !o.fixed) dmg = Math.round(dmg * DIFF.dmg);
  P.hp -= dmg; P.inv = 0.85; SFX.hurt(); G.cam.shake = Math.max(G.cam.shake, 4); G.flash = 0.08; G.flashCol = '#c8402e';
  if (!o.pit) { const dir = srcX == null ? -P.f : (P.x + 5 < srcX ? -1 : 1); P.vx = dir * 120; P.vy = -130; P.state = 'hurt'; P.stT = 0; }
  for (let i = 0; i < 8; i++) part(P.x + 5, P.y + 10, rnd(-60, 60), rnd(-80, -10), 0.4, '#c8402e');
  if (P.hp <= 0) die();
  return true;
}

// ---------- Inimigos ----------
const ET = {
  crawler: { w: 14, h: 9, hp: 22, dmg: 12, spd: 30, mem: 8 },
  flyer: { w: 14, h: 11, hp: 15, dmg: 10, spd: 40, mem: 7, fly: true },
  spitter: { w: 10, h: 14, hp: 20, dmg: 11, mem: 9 },
  brute: { w: 16, h: 24, hp: 60, dmg: 22, spd: 26, mem: 18, reach: 22, wind: 0.5 },
  lanceiro: { w: 12, h: 22, hp: 45, dmg: 18, spd: 32, mem: 14, reach: 34, wind: 0.42 },
  wolf: { w: 26, h: 15, hp: 120, dmg: 14, spd: 95, mem: 30 },
  // fauna corrompida: cada bicho usa um dos comportamentos acima (ai)
  tatu: { ai: 'crawler', w: 14, h: 9, hp: 24, dmg: 12, spd: 32, mem: 8 },
  capivara: { ai: 'crawler', w: 20, h: 13, hp: 40, dmg: 14, spd: 22, mem: 11 },
  urubu: { ai: 'flyer', w: 16, h: 10, hp: 16, dmg: 10, spd: 42, mem: 8, fly: true },
  cobra: { ai: 'spitter', w: 14, h: 12, hp: 22, dmg: 11, mem: 9 },
  queixada: { ai: 'brute', w: 20, h: 14, hp: 58, dmg: 20, spd: 30, mem: 16, reach: 20, wind: 0.48 },
  tamandua: { ai: 'brute', w: 22, h: 16, hp: 66, dmg: 22, spd: 22, mem: 18, reach: 26, wind: 0.55 },
  jaguatirica: { ai: 'wolf', w: 22, h: 13, hp: 42, dmg: 14, spd: 100, mem: 15 },
  lobo: { ai: 'wolf', w: 22, h: 16, hp: 46, dmg: 15, spd: 88, mem: 15 },
};
// qual bicho ocupa cada papel em cada bioma
const FAUNA = {
  prologo: { crawler: ['tatu'], flyer: ['urubu'], spitter: ['cobra'], brute: ['queixada'], lanceiro: ['lobo'] },
  amazonia: { crawler: ['capivara', 'tatu'], flyer: ['urubu'], spitter: ['cobra'], brute: ['queixada'], lanceiro: ['jaguatirica'] },
  cerrado: { crawler: ['tatu'], flyer: ['urubu'], spitter: ['cobra'], brute: ['tamandua'], lanceiro: ['lobo'] },
  pantanal: { crawler: ['capivara'], flyer: ['urubu'], spitter: ['cobra'], brute: ['queixada'], lanceiro: ['jaguatirica'] },
  caatinga: { crawler: ['tatu'], flyer: ['urubu'], spitter: ['cobra'], brute: ['queixada'], lanceiro: ['lobo'] },
  mata: { crawler: ['capivara', 'tatu'], flyer: ['urubu'], spitter: ['cobra'], brute: ['tamandua', 'queixada'], lanceiro: ['jaguatirica'] },
};
const EYE = { prologo: '#ffe066', amazonia: '#c8f060', cerrado: '#ff8a3a', pantanal: '#e070c0', caatinga: '#ffd27a', mata: '#9fe0d0', coracao: '#ff6a3a' };
function spawnEnemies() { G.ents = G.lvl.spawns.map(s => makeEnemy(s.type, s.x, s.y)); }
function makeEnemy(type, x, y) {
  const fz = FAUNA[G.lvl.biome] || FAUNA.amazonia;
  if (fz[type]) { const opts = fz[type]; type = opts[Math.floor(hash(Math.round(x) * 7 + 3) * opts.length)]; }
  const d = ET[type], a = G.lvl.act || 0, personality = hash(Math.round(x * 13) + type.length * 71);
  const e = { type, x, y: 0, w: d.w, h: d.h, vx: 0, vy: 0, f: -1, hp: Math.round(d.hp * (1 + 0.45 * a) * DIFF.enemyHp), dmg: Math.round(d.dmg * (1 + 0.25 * a)), spd: (d.spd || (d.ai === 'spitter' || type === 'spitter' ? 22 : 0)) * (1 + 0.08 * a), t: rnd(0, 5), flash: 0, wind: 0, swing: 0, rec: 0, cd: 0.65 + personality * 0.65, hx: x, hy: y, poison: 0, pt: 0, mem: d.mem + a * 3, mode: 'home', onG: false,
    personality, gait: 0, aware: false, memory: 0, alertT: 0, patrolPause: 0, attacks: 0, motion: { phase: 'idle', progress: 0, variant: '' } };
  e.hpMax = e.hp; e.ai = d.ai || type; e.y = (y == null ? groundY(x + d.w / 2) : y) - d.h;
  if (d.fly) e.hy = e.y; else e.stepH = 18;
  return e;
}
function enemyPatrolBounds(e) {
  const min = G.lvl.enemyMinX;
  if (min == null || e.x >= min) return;
  e.x = min; e.f = 1; e.vx = Math.abs(e.vx);
}
function enemyMotion(e, phase, progress = 0, variant = e.attackVariant || '') {
  const m = e.motion || (e.motion = {}); m.phase = phase; m.progress = clamp(progress, 0, 1); m.variant = variant;
}
function enemySight(e, px, py) {
  const ex = e.x + e.w / 2, ey = e.y + e.h * 0.35;
  for (let t = 0.15; t < 0.95; t += 0.15) { const s = solidAt(lerp(ex, px, t), lerp(ey, py, t)); if (s && s.t === 'g' && (s.wall || s.block)) return false; }
  return true;
}
function enemyNotice(e, dx, dy, dt) {
  const range = e.ai === 'spitter' ? 175 : e.ai === 'wolf' ? 165 : e.ai === 'flyer' ? 140 : 125;
  const P = G.P, safe = G.lvl.enemyMinX != null && P.x + 5 < G.lvl.enemyMinX;
  const seen = !safe && Math.abs(dx) < range && Math.abs(dy) < (ET[e.type].fly ? 115 : 48) && enemySight(e, P.x + 5, P.y + 11);
  e.alertT = Math.max(0, e.alertT - dt);
  if (seen) {
    if (!e.aware) { e.alertMax = 0.24 + e.personality * 0.16; e.alertT = e.alertMax; }
    e.aware = true; e.memory = 2.1 + e.personality; e.lastSeen = P.x + 5;
  } else { e.memory = safe ? 0 : Math.max(0, e.memory - dt); if (!e.memory) e.aware = false; }
  e.cd = Math.max(0, e.cd - dt);
}
// Vizinhos se alternam para dar tempo de reconhecer os avisos.
function enemyCanAttack(e) {
  if (e.cd > 0 || e.alertT > 0 || (G.enemyAttackGap || 0) > 0 || !e.aware) return false;
  let active = 0;
  for (const o of G.ents) if (o !== e && o.hp > 0 && o.motion && ['windup', 'attack'].includes(o.motion.phase)) {
    active++;
    if (!ET[e.type].fly && !ET[o.type].fly && Math.abs(o.x - e.x) < 80 && Math.abs(o.y - e.y) < 36) return false;
  }
  return active < 2;
}
function enemyPrepare(e, wind, variant) {
  e.wind = e.windMax = wind; e.swing = e.rec = 0; e.attackVariant = variant; e.vx = 0;
  e.contactHit = e.hitDone = false; e.attacks++; G.enemyAttackGap = 0.2; enemyMotion(e, 'windup');
}
function enemyRecover(e, duration) {
  e.wind = e.swing = 0; e.rec = e.recMax = duration; e.noTouch = true; e.cd = 0.65 + e.personality * 0.5; enemyMotion(e, 'recover');
}
function enemyMove(e, target, dt, spacing = true) {
  const previous = e.f;
  if (target && e.onG) { e.f = Math.sign(target); if (pitAhead(e, Math.max(3, Math.abs(target) * dt + 3))) target = 0; e.f = previous; }
  if (target && spacing) for (const o of G.ents) if (o !== e && o.hp > 0 && !ET[o.type].fly && Math.abs(o.y - e.y) < 24) {
    const dx = e.x + e.w / 2 - (o.x + o.w / 2), gap = (e.w + o.w) / 2 + 8;
    if (Math.abs(dx) < gap && Math.sign(target) === -Math.sign(dx)) target *= 0.2;
  }
  e.vx = lerp(e.vx, target, 1 - Math.exp(-13 * dt));
  if (!target && e.onG && Math.abs(e.vx) > 0.1) { e.f = Math.sign(e.vx); if (pitAhead(e, Math.abs(e.vx) * dt + 3)) e.vx = 0; e.f = previous; }
}
function enemyPatrol(e, dt) {
  e.patrolPause = Math.max(0, e.patrolPause - dt);
  const radius = 42 + e.personality * 40, min = Math.max(G.lvl.enemyMinX || 0, e.hx - radius), max = Math.min(G.lvl.w - e.w, e.hx + radius);
  if (e.x <= min && e.f < 0 || e.x >= max && e.f > 0 || e.hitWall || e.onG && pitAhead(e)) { e.f *= -1; e.patrolPause = 0.3 + e.personality * 0.6; }
  return e.patrolPause > 0 ? 0 : e.f * e.spd * 0.5;
}
function enemyGround(e, dt) { e.vy += GRAV * dt; moveBody(e, dt); }
function updateEnemies(dt) {
  if (!G.P) return;
  // Uma cena congela decisões e ataques; ao voltar, o aviso ainda pode ser lido.
  if (G.lock > 0 || G.P.state === 'dead' || G.grace > 0) { G.grace = Math.max(0, (G.grace || 0) - dt); for (const e of G.ents) { e.t += dt; enemyMotion(e, 'idle'); } return; }
  G.enemyAttackGap = Math.max(0, (G.enemyAttackGap || 0) - dt);
  const P = G.P, px = P.x + 5, py = P.y + 11;
  for (const e of G.ents) {
    if (e.hp <= 0) continue;
    e.t += dt; e.flash -= dt;
    if (e.poison > 0) { e.poison -= dt; e.pt -= dt; if (e.pt <= 0) { e.pt = 0.5; e.hp -= 3; e.flash = 0.06; part(e.x + e.w / 2, e.y, 0, -20, 0.5, '#8fe37a'); if (e.hp <= 0) { killEnemy(e); continue; } } }
    const d = ET[e.type], dx = px - (e.x + e.w / 2), dy = py - (e.y + e.h / 2), generic = ['crawler', 'flyer', 'spitter', 'brute', 'lanceiro', 'wolf'].includes(e.ai);
    if (Math.abs(dx) > 260) continue;
    if (e.stag > 0) {
      if (generic && !e.interrupted) { enemyRecover(e, 0.4); e.contactHit = true; if (e.ai === 'wolf') { e.st = 'rest'; e.tt = 0.4; } if (e.ai === 'flyer') e.mode = 'tired'; e.interrupted = true; }
      e.stag -= dt; e.vx *= Math.pow(0.02, dt); enemyMotion(e, 'recover', 0.3, 'hurt');
      if (d.fly) { e.x += e.vx * dt; e.y += e.vy * dt; e.vy *= Math.pow(0.05, dt); } else enemyGround(e, dt);
      enemyPatrolBounds(e); if (e.y > (G.lvl.h || WORLD_H) + 60) e.hp = 0; continue;
    }
    e.interrupted = false;
    if (generic) {
      enemyNotice(e, dx, dy, dt); e.noTouch = true;
      if (G.lvl.enemyMinX != null && px < G.lvl.enemyMinX && (e.wind > 0 || e.swing > 0)) {
        enemyRecover(e, 0.4); e.vx = 0;
        if (e.ai === 'wolf') e.st = 'rest';
        if (e.ai === 'flyer') e.mode = 'tired';
      }
    }
    if (e.ai === 'crawler') {
      if (e.swing > 0) {
        e.swing = Math.max(0, e.swing - dt); e.noTouch = false; enemyMove(e, e.f * e.spd * (e.type === 'tatu' ? 3.1 : 2.3), dt, false); enemyMotion(e, 'attack', 1 - e.swing / e.swingMax);
        if (!e.swing) enemyRecover(e, 0.6 + e.personality * 0.25);
      } else if (e.wind > 0) {
        e.wind = Math.max(0, e.wind - dt); enemyMove(e, 0, dt); enemyMotion(e, 'windup', 1 - e.wind / e.windMax);
        if (!e.wind) { e.swing = e.swingMax = e.type === 'tatu' ? 0.34 : 0.24; SFX.swing(); }
      } else if (e.rec > 0) { e.rec = Math.max(0, e.rec - dt); enemyMove(e, 0, dt); enemyMotion(e, 'recover', 1 - e.rec / e.recMax); }
      else if (e.aware && !e.alertT) {
        const target = e.lastSeen - (e.x + e.w / 2); e.f = Math.sign(target) || e.f;
        if (Math.abs(dx) < (e.type === 'tatu' ? 48 : 35) && Math.abs(dy) < 32 && enemyCanAttack(e)) enemyPrepare(e, 0.34 + e.personality * 0.12, e.type === 'tatu' ? 'roll' : 'shove');
        else { enemyMove(e, Math.abs(target) > 22 ? e.f * e.spd * 1.25 : 0, dt); enemyMotion(e, Math.abs(e.vx) > 3 ? 'move' : 'idle'); }
      } else { enemyMove(e, e.aware ? 0 : enemyPatrol(e, dt), dt); enemyMotion(e, e.alertT > 0 ? 'alert' : Math.abs(e.vx) > 3 ? 'move' : 'idle', e.alertT > 0 ? 1 - e.alertT / e.alertMax : 0); }
      enemyGround(e, dt);
    } else if (e.ai === 'flyer') {
      if (e.mode === 'aim') {
        e.wind = Math.max(0, e.wind - dt); e.st = e.wind;
        if (e.wind > e.windMax * 0.5) { e.aimX = px + clamp(P.vx, -80, 80) * 0.12; e.aimY = py; }
        enemyMotion(e, 'windup', 1 - e.wind / e.windMax);
        if (!e.wind) { const ax = e.aimX - (e.x + e.w / 2), ay = e.aimY - (e.y + e.h / 2), len = Math.hypot(ax, ay) || 1; e.vx = ax / len * 138; e.vy = ay / len * 138; e.swing = e.swingMax = 0.62; e.mode = 'swoop'; }
      } else if (e.mode === 'swoop') {
        e.swing = Math.max(0, e.swing - dt); e.st = e.swing; e.noTouch = false; e.x += e.vx * dt; e.y += e.vy * dt;
        const gy = groundY(e.x + e.w / 2, e.y); if (e.y + e.h > gy - 2) { e.y = gy - e.h - 2; e.vy = 0; }
        enemyMotion(e, 'attack', 1 - e.swing / e.swingMax); if (!e.swing) { e.mode = 'tired'; enemyRecover(e, 0.85 + e.personality * 0.3); }
      } else if (e.mode === 'tired') {
        e.rec = Math.max(0, e.rec - dt); e.st = e.rec; e.vx *= Math.exp(-9 * dt); e.x += e.vx * dt; enemyMotion(e, 'recover', 1 - e.rec / e.recMax); if (!e.rec) e.mode = 'home';
      } else {
        const tx = e.aware ? clamp(e.lastSeen + Math.sin(e.t * 1.2 + e.personality * 6) * 32, e.hx - 85, e.hx + 85) : e.hx + Math.sin(e.t * 1.2) * 28, ty = e.hy + Math.sin(e.t * 2.1) * 8;
        const oldX = e.x; e.x += clamp(tx - e.x, -e.spd * dt, e.spd * dt); e.y += clamp(ty - e.y, -e.spd * dt, e.spd * dt); e.vx = (e.x - oldX) / dt; e.f = Math.sign(dx) || e.f;
        enemyMotion(e, e.alertT > 0 ? 'alert' : 'move', e.alertT > 0 ? 1 - e.alertT / e.alertMax : 0);
        if (Math.abs(dx) < 120 && Math.abs(dy) < 105 && enemyCanAttack(e)) { enemyPrepare(e, 0.48 + e.personality * 0.14, 'dive'); e.mode = 'aim'; e.aimX = px; e.aimY = py; }
      }
    } else if (e.ai === 'spitter') {
      if (e.wind > 0) {
        e.wind = Math.max(0, e.wind - dt); enemyMove(e, 0, dt);
        if (e.wind > e.windMax * 0.5) { e.aimX = px + clamp(P.vx, -60, 60) * 0.16; e.aimY = py; }
        enemyMotion(e, 'windup', 1 - e.wind / e.windMax);
        if (!e.wind) {
          const T = clamp(Math.abs(e.aimX - (e.x + e.w / 2)) / 145, 0.45, 0.85), ay = e.aimY - (e.y + 4);
          shoot({ team: 'e', owner: e, x: e.x + e.w / 2, y: e.y + 4, vx: clamp((e.aimX - (e.x + e.w / 2)) / T, -150, 150), vy: clamp((ay - 0.5 * 400 * T * T) / T, -260, 80), w: 5, h: 5, dmg: e.dmg, kind: 'blob', grav: 400 });
          e.swing = e.swingMax = 0.16; SFX.swing();
        }
      } else if (e.swing > 0) { e.swing = Math.max(0, e.swing - dt); enemyMove(e, 0, dt); enemyMotion(e, 'attack', 1 - e.swing / e.swingMax); if (!e.swing) enemyRecover(e, 0.65); }
      else if (e.rec > 0) { e.rec = Math.max(0, e.rec - dt); enemyMove(e, 0, dt); enemyMotion(e, 'recover', 1 - e.rec / e.recMax); }
      else if (e.aware && !e.alertT) {
        e.f = Math.sign(dx) || e.f;
        if (Math.abs(dx) < 165 && Math.abs(dy) < 65 && enemyCanAttack(e)) { enemyPrepare(e, 0.58 + e.personality * 0.14, 'spit'); e.aimX = px; e.aimY = py; }
        else { enemyMove(e, Math.abs(dx) < 55 ? -e.f * e.spd : Math.abs(dx) > 125 ? e.f * e.spd * 0.6 : 0, dt); enemyMotion(e, Math.abs(e.vx) > 3 ? 'move' : 'idle'); }
      } else { enemyMove(e, 0, dt); enemyMotion(e, e.alertT > 0 ? 'alert' : 'idle', e.alertT > 0 ? 1 - e.alertT / e.alertMax : 0); }
      enemyGround(e, dt);
    } else if (e.ai === 'brute' || e.ai === 'lanceiro') {
      if (e.swing > 0) {
        e.swing = Math.max(0, e.swing - dt); enemyMove(e, e.attackVariant === 'lunge' ? e.f * e.spd * 1.4 : 0, dt, false); enemyMotion(e, 'attack', 1 - e.swing / e.swingMax);
        const hb = { x: e.f > 0 ? e.x + e.w : e.x - d.reach, y: e.y + 2, w: d.reach, h: e.h - 4 };
        if (!e.hitDone && overlap(hb, P)) { e.hitDone = true; hurtPlayer(e.dmg, e.x + e.w / 2); }
        if (!e.swing) enemyRecover(e, 0.7 + e.personality * 0.3);
      } else if (e.wind > 0) {
        e.wind = Math.max(0, e.wind - dt); enemyMove(e, 0, dt); enemyMotion(e, 'windup', 1 - e.wind / e.windMax);
        if (!e.wind) { e.swing = e.swingMax = e.attackVariant === 'lunge' ? 0.22 : 0.28; e.hitDone = false; SFX.swing(); }
      } else if (e.rec > 0) { e.rec = Math.max(0, e.rec - dt); enemyMove(e, 0, dt); enemyMotion(e, 'recover', 1 - e.rec / e.recMax); }
      else if (e.aware && !e.alertT) {
        const target = e.lastSeen - (e.x + e.w / 2); e.f = Math.sign(target) || e.f;
        if (Math.abs(dx) < d.reach + e.w / 2 + 3 && Math.abs(dy) < 38 && enemyCanAttack(e)) enemyPrepare(e, d.wind + e.personality * 0.12, (e.attacks + Math.round(e.personality * 3)) % 2 ? 'lunge' : 'sweep');
        else { enemyMove(e, Math.abs(target) > d.reach * 0.8 ? e.f * e.spd : 0, dt); enemyMotion(e, Math.abs(e.vx) > 3 ? 'move' : 'idle'); }
      } else { enemyMove(e, e.aware ? 0 : enemyPatrol(e, dt), dt); enemyMotion(e, e.alertT > 0 ? 'alert' : Math.abs(e.vx) > 3 ? 'move' : 'idle', e.alertT > 0 ? 1 - e.alertT / e.alertMax : 0); }
      enemyGround(e, dt);
    } else if (e.ai === 'wolf') updateWolf(e, dt, dx, dy);
    else if (typeof CAVE_AI !== 'undefined' && CAVE_AI[e.ai]) CAVE_AI[e.ai](e, dt, dx, dy);
    e.gait = (e.gait || 0) + Math.abs(e.vx) * dt * 0.24; enemyPatrolBounds(e);
    if (overlap(e, P) && !e.noTouch && !e.contactHit && e.ai !== 'brute' && e.ai !== 'lanceiro') { e.contactHit = true; hurtPlayer(e.dmg, e.x + e.w / 2); }
    if (e.y > (G.lvl.h || WORLD_H) + 60) e.hp = 0;
  }
  G.ents = G.ents.filter(e => e.hp > 0 || e.keep);
}
function pitAhead(e, look = 2) {
  const ax = e.f > 0 ? e.x + e.w + look : e.x - look, foot = e.y + e.h;
  for (let y = foot + 1; y <= foot + 40; y += 2) if (solidAt(ax, y)) return false;
  for (const r of G.lvl.ramps) if (ax > Math.min(r.x0, r.x1) && ax < Math.max(r.x0, r.x1)) return false;
  return true;
}
function updateWolf(e, dt, dx, dy = 0) {
  e.st = e.st || 'run';
  if (e.st === 'wind') {
    e.wind = Math.max(0, e.wind - dt); e.tt = e.wind; enemyMove(e, 0, dt); enemyMotion(e, 'windup', 1 - e.wind / e.windMax);
    if (!e.wind) {
      if (pitAhead(e, 48)) { e.st = 'rest'; enemyRecover(e, 0.6); }
      else { e.st = 'leap'; e.swing = e.swingMax = 0.65; e.vy = e.attackVariant === 'short-hop' ? -170 : -225; e.vx = e.f * (e.attackVariant === 'short-hop' ? 120 : 165); SFX.roar(); }
    }
  } else if (e.st === 'leap') {
    e.swing = Math.max(0, e.swing - dt); e.noTouch = false; enemyMotion(e, 'attack', 1 - e.swing / e.swingMax);
    if (e.onG && e.vy >= 0 || !e.swing) { e.st = 'rest'; enemyRecover(e, 0.85 + e.personality * 0.3); }
  } else if (e.st === 'rest') {
    e.rec = Math.max(0, e.rec - dt); e.tt = e.rec; enemyMove(e, 0, dt); enemyMotion(e, 'recover', 1 - e.rec / e.recMax); if (!e.rec) e.st = 'run';
  } else if (e.aware && !e.alertT) {
    const target = e.lastSeen - (e.x + e.w / 2); e.f = Math.sign(target) || e.f;
    if (Math.abs(dx) < 78 && Math.abs(dy) < 42 && e.onG && enemyCanAttack(e)) { e.st = 'wind'; enemyPrepare(e, 0.4 + e.personality * 0.15, Math.abs(dx) < 42 ? 'short-hop' : 'pounce'); e.tt = e.wind; }
    else { enemyMove(e, Math.abs(target) > 42 ? e.f * e.spd * 0.85 : 0, dt); enemyMotion(e, Math.abs(e.vx) > 3 ? 'move' : 'idle'); }
  } else { enemyMove(e, e.aware ? 0 : enemyPatrol(e, dt), dt); enemyMotion(e, e.alertT > 0 ? 'alert' : Math.abs(e.vx) > 3 ? 'move' : 'idle', e.alertT > 0 ? 1 - e.alertT / e.alertMax : 0); }
  enemyGround(e, dt);
}

function hitEnemy(e, dmg, dir, o = {}) {
  if (e.shell && dir && dir === -e.f) { shellBlock(e); return false; }
  e.hp -= dmg; e.flash = 0.1; SFX.hit();
  if (e.fixed) { /* não se move */ }
  else if (o.melee && dir) {
    // golpe de perto empurra e atordoa um instante: o monstro não fica colado causando dano
    const heavy = e.ai === 'brute' || e.ai === 'lanceiro';
    e.vx = dir * (heavy ? 110 : 190); e.stag = heavy ? 0.22 : 0.38;
    if (ET[e.type].fly) { e.vy = -50; e.mode = 'home'; } else if (!heavy) e.vy = -90;
    if (heavy) { e.wind = 0; e.swing = 0; e.rec = 0.2; }
  } else if (e.ai !== 'brute' && e.ai !== 'wolf') { e.vx += dir * 50; if (!ET[e.type].fly) e.vy = -40; }
  if (o.poison) e.poison = 3;
  for (let i = 0; i < 5; i++) part(e.x + e.w / 2, e.y + e.h / 2, dir * rnd(20, 80), rnd(-60, 10), 0.35, '#2a2230');
  if (e.hp <= 0) killEnemy(e);
  return true;
}
function killEnemy(e) {
  e.hp = 0;
  const eye = EYE[G.lvl.biome];
  for (let i = 0; i < 16; i++) part(e.x + e.w / 2, e.y + e.h / 2, rnd(-70, 70), rnd(-90, 10), rnd(0.4, 0.9), i % 4 ? '#1c1622' : eye);
  G.save.mem += e.mem; floatText(e.x + e.w / 2, e.y - 4, '+' + e.mem); SFX.mem();
  if (e.onDeath) e.onDeath(e);
}

// ---------- Projéteis ----------
function shoot(o) { G.projs.push(Object.assign({ team: 'p', life: 2.2, grav: 0, set: new Set() }, o)); }
function updateProjs(dt) {
  const P = G.P;
  for (const p of G.projs) {
    p.life -= dt; p.vy += p.grav * dt; p.x += p.vx * dt; p.y += p.vy * dt;
    const box = { x: p.x - p.w / 2, y: p.y - p.h / 2, w: p.w, h: p.h };
    if (p.kind === 'fire' && Math.random() < 0.6) part(p.x, p.y, rnd(-10, 10), rnd(-20, 0), 0.3, pick(['#ffd27a', '#e0703a']));
    const s = solidAt(p.x, p.y);
    if (s && s.t === 'g') {
      p.life = 0;
      if (p.team === 'p') emitNoise(p.x, p.y, 120);
      if (p.land) p.land(p, s);
      if (p.kind === 'fire') addHazard({ kind: 'pfire', x: p.x - 18, y: s.y - 10, w: 36, h: 10, t: 0, life: 3, dmg: 4, team: 'p', tick: 0 });
      if (p.kind === 'rock') { SFX.boom(); G.cam.shake = 3; for (let i = 0; i < 4; i++) shoot({ team: 'e', x: p.x, y: s.y - 4, vx: rnd(-90, 90), vy: rnd(-180, -80), w: 4, h: 4, dmg: 8, kind: 'pebble', grav: 500, life: 1.2 }); }
      for (let i = 0; i < 4; i++) part(p.x, p.y, rnd(-30, 30), rnd(-40, 0), 0.3, '#5a4a40');
      continue;
    }
    if (p.team === 'p') {
      for (const e of G.ents) if (e.hp > 0 && !p.set.has(e) && overlap(box, e)) { p.set.add(e); if (hitEnemy(e, p.dmg, Math.sign(p.vx), p) === false) { p.life = 0; break; } if (p.kind === 'fire') addHazard({ kind: 'pfire', x: e.x + e.w / 2 - 18, y: groundY(e.x + e.w / 2, e.y) - 10, w: 36, h: 10, t: 0, life: 3, dmg: 4, team: 'p', tick: 0 }); if (!p.pierce) { p.life = 0; break; } }
      const B = G.boss;
      if (p.life > 0 && B && !p.set.has(B) && overlap(box, bossBox(B))) { p.set.add(B); if (bossHurt(B, p.dmg, Math.sign(p.vx), p)) { if (p.kind === 'fire') addHazard({ kind: 'pfire', x: B.x - 18, y: GY - 10, w: 36, h: 10, t: 0, life: 3, dmg: 4, team: 'p', tick: 0 }); if (!p.pierce) p.life = 0; } }
    } else if (overlap(box, P)) {
      if (hurtPlayer(p.dmg, p.x)) { if (p.onHit) p.onHit(p); p.life = 0; }
    }
  }
  G.projs = G.projs.filter(p => p.life > 0 && p.x > G.cam.x - 80 && p.x < G.cam.x + W + 80 && p.y < (G.lvl.h || WORLD_H) + 40 && p.y > G.cam.y - 120);
}

// ---------- Perigos (gás, fogo, ondas de choque, raízes...) ----------
function addHazard(h) { G.hazards.push(Object.assign({ t: 0, tick: 0 }, h)); return h; }
const HZ = {
  pfire: { update(h, dt) { h.tick -= dt; if (h.tick <= 0) { h.tick = 0.4; for (const e of G.ents) if (e.hp > 0 && overlap(h, e)) hitEnemy(e, h.dmg, 0); const B = G.boss; if (B && overlap(h, bossBox(B))) bossHurt(B, h.dmg, 0, { quiet: true }); } if (Math.random() < 0.5) part(h.x + rnd(0, h.w), h.y + h.h, rnd(-5, 5), rnd(-40, -15), 0.4, pick(['#ffd27a', '#e0703a', '#c8402e'])); },
    draw(h) { for (let i = 0; i < h.w; i += 3) { const fh = 3 + Math.abs(Math.sin(G.t * 9 + i)) * 6 * Math.min(1, h.life); rect(ctx, h.x + i, h.y + h.h - fh, 2, fh, i % 2 ? '#e0703a' : '#ffd27a'); } } },
  fire: { update(h, dt) { h.tick -= dt; if (h.t > 0.6 && overlap(h, G.P) && h.tick <= 0) { h.tick = 0.45; hurtPlayer(h.dmg, null, { force: false }) || (G.P.inv <= 0 && 0); } if (Math.random() < 0.6) part(h.x + rnd(0, h.w), h.y + h.h, rnd(-5, 5), rnd(-50, -20), 0.5, pick(['#ffd27a', '#e0703a', '#c8402e'])); },
    draw(h) { const k = Math.min(1, h.t / 0.6); ctx.globalAlpha = h.t < 0.6 ? 0.5 + Math.sin(G.t * 30) * 0.3 : 1; for (let i = 0; i < h.w; i += 2) { const fh = (4 + Math.abs(Math.sin(G.t * 8 + i * 0.7)) * 9) * k; rect(ctx, h.x + i, h.y + h.h - fh, 2, fh, i % 4 ? '#e0703a' : '#ffd27a'); } ctx.globalAlpha = 1; } },
  gas: { update(h, dt) { h.x += h.vx * dt; h.y += Math.sin(h.t * 2) * 6 * dt; if (overlap(h, G.P) && G.P.state !== 'dead') { G.P.slow = 0.3; G.P.st = Math.max(0, G.P.st - 30 * dt); G.P.stDelay = 0.3; if (h.stun && !h.used) { h.used = true; G.P.stun = 0.6; floatText(G.P.x + 5, G.P.y - 6, 'atordoado', '#c8f060'); } } },
    draw(h) { const a = Math.min(1, h.life) * 0.55; ctx.globalAlpha = a; for (let i = 0; i < 6; i++) ell(ctx, h.x + h.w / 2 + Math.sin(G.t * 2 + i) * h.w * 0.3, h.y + h.h / 2 + Math.cos(G.t * 1.7 + i * 2) * h.h * 0.25, h.w * 0.32 | 0, h.h * 0.3 | 0, i % 2 ? '#7a9a3a' : '#9aba4a'); ctx.globalAlpha = 1; } },
  shock: { update(h, dt) { h.x += h.vx * dt; if (!h.hit && overlap(h, G.P)) h.hit = hurtPlayer(h.dmg, h.x); if (Math.random() < 0.7) part(h.x + h.w / 2, h.y + h.h, rnd(-20, 20), rnd(-60, -20), 0.3, h.col || '#7a5a3a'); if (solidAt(h.x + (h.vx > 0 ? h.w : 0), h.y + h.h - 2)) h.life = 0; },
    draw(h) { for (let i = 0; i < 4; i++) rect(ctx, h.x + i * 2, h.y + h.h - (6 - Math.abs(i - 1.5) * 2) * 1.6, 2, (6 - Math.abs(i - 1.5) * 2) * 1.6, h.col || '#a87a4a'); } },
  roots: { update(h, dt) { if (h.t > h.warn && !h.hit && overlap(h, G.P)) h.hit = hurtPlayer(h.dmg, h.x + h.w / 2); if (h.t > h.warn && !h.snd) { h.snd = true; SFX.hit(); } },
    draw(h) { const gy = h.y + h.h; if (h.t < h.warn) { ctx.globalAlpha = 0.5 + Math.sin(G.t * 25) * 0.4; for (let i = 0; i < h.w; i += 3) rect(ctx, h.x + i, gy - 1, 2, 1, h.col || '#c8803a'); ctx.globalAlpha = 1; } else { const k = Math.min(1, (h.t - h.warn) / 0.08) * Math.min(1, h.life / 0.2); for (let i = 0; i < h.w; i += 4) { const hh = h.h * k * (0.6 + 0.4 * Math.abs(Math.sin(i))); line(ctx, h.x + i + 2, gy, h.x + i + 2 + Math.sin(i) * 3, gy - hh, h.col2 || '#5a3a22', 2); } } } },
  proots: { update(h) { if (h.t > 0.22) { for (const e of G.ents) if (e.hp > 0 && !h.set.has(e) && overlap(h, e)) { h.set.add(e); hitEnemy(e, h.dmg, 0); } const B = G.boss; if (B && !h.set.has(B) && overlap(h, bossBox(B))) { h.set.add(B); bossHurt(B, h.dmg, 0); } } },
    draw(h) { drawRootBurst(h); } },
};
function updateHazards(dt) {
  for (const h of G.hazards) { h.t += dt; h.life -= dt; const d = HZ[h.kind] || h; if (d.update) d.update(h, dt); }
  G.hazards = G.hazards.filter(h => h.life > 0);
}

// ---------- Partículas e textos flutuantes ----------
function part(x, y, vx, vy, life, col, s = 1, g = 120) { if (G.parts.length < 600) G.parts.push({ x, y, vx, vy, life, max: life, col, s, g }); }
function splash(x, y) { SFX.splash(); for (let i = 0; i < 12; i++) part(x + rnd(-6, 6), y, rnd(-40, 40), rnd(-110, -40), 0.5, i % 2 ? '#c8d8f0' : '#8aa8d0', 1, 400); }
function updateParts(dt) {
  for (const p of G.parts) { p.life -= dt; p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
  G.parts = G.parts.filter(p => p.life > 0);
  const b = G.lvl && biome(G.lvl.biome);
  if (b && Math.random() < 0.08) G.parts.push({ x: G.cam.x + rnd(0, W), y: rnd(50, 148), vx: rnd(-6, 6), vy: rnd(-5, 2), life: 4, max: 4, col: b.motes, s: 1, g: 0, mote: true });
}
function floatText(wx, wy, txt, col) {
  const el = document.createElement('span');
  el.textContent = txt; if (col) el.style.color = col;
  el.style.left = ((wx - G.cam.x) / W * 100) + '%'; el.style.top = ((wy - G.cam.y) / H * 100) + '%';
  $('#float').appendChild(el); setTimeout(() => el.remove(), 1000);
}

// ---------- Câmera ----------
function updateCamera(dt) {
  const P = G.P, L = G.lvl, A = L.arena;
  let tx = P.x + 5 - W / 2 + P.f * 22;
  let lo = 0, hi = L.w - W;
  if (A && A.active) { lo = hi = clamp(A.x0 - (W - AW) / 2, 0, L.w - W); }
  if (G.camTarget != null) tx = G.camTarget;
  tx = clamp(tx, lo, hi);
  G.cam.x = lerp(G.cam.x, tx, Math.min(1, dt * 6));
  if (Math.abs(G.cam.x - tx) < 0.2) G.cam.x = tx;
  G.cam.shake = Math.max(0, G.cam.shake - dt * 18);
}

// ---------- Desenho do mundo ----------
function renderWorld() {
  const L = G.lvl, b = biome(L.biome), cx = G.cam.x, t = G.t;
  ctx.save(); ctx.translate(0, DY);
  drawBackground(b, cx, t);
  if (L.biome === 'cerrado' && G.save.ev && G.save.ev.boitata) drawSkyBoitata(t);
  // cenário progressivo: o fundo escurece e se corrompe à medida que o guardião se aproxima
  const prog = clamp(cx / Math.max(1, (L.arena ? L.arena.x0 : L.w - W)), 0, 1);
  if (prog > 0) { ctx.globalAlpha = prog * 0.38; rect(ctx, 0, -DY, W, H, tpal(L.biome).corrupt); ctx.globalAlpha = 1; }
  if (!L.cave) drawWorldAtmosphere(L.biome, b, t);
  const sx = G.cam.shake ? rnd(-G.cam.shake, G.cam.shake) : 0, sy = G.cam.shake ? rnd(-G.cam.shake, G.cam.shake) : 0;
  ctx.save(); ctx.translate(-cx + Math.round(sx), Math.round(sy));
  const gp = b.ground;
  // sombras da caatinga
  for (const s of L.shade) drawShadeZone(s, b);
  for (const s of G.dynShade) {
    ctx.globalAlpha = 0.85; ell(ctx, s.x + s.w / 2, 26, s.w / 2 + 10, 6, '#f4ecd8'); ell(ctx, s.x + s.w / 2 - 6, 22, s.w / 3, 4, '#fffaf0');
    ctx.globalAlpha = 0.1; rect(ctx, s.x, 32, s.w, GY - 32, '#3a2a20');
    ctx.globalAlpha = 1;
  }
  // decoração de fundo
  for (const p of L.props) if (p.x > cx - 120 && p.x < cx + W + 120) drawProp(p, t);
  if (!L.cave) {
    for (const cn of L.canopies) if (cn.tx != null && cn.x + cn.w > cx - 40 && cn.x < cx + W + 40) drawTreeTrunk(cn.tx, cn.tw, 24 + (cn.y || 0), L.biome, cn.x);
    for (const o of L.hvines) if (o.tx != null && o.x > cx - 40 && o.x < cx + W + 40) drawTreeTrunk(o.tx, 6, 10, L.biome, o.x + 7);
  }
  for (const f of L.fires) if (f.x > cx - 40 && f.x < cx + W + 40) drawFire(ctx, f.x, groundY(f.x), t, !!G.save.lit[f.id]);
  drawCaveBack(L, cx, t);
  const E = L.echoAt;
  if (E && E.x > cx - 40 && E.x < cx + W + 40) drawEcho(E, t);
  const d = G.save.drop;
  if (d && d.lvl === L.id) drawSparkle(ctx, d.x, d.y + 3, t, '#f6e3a6');
  // chão e plataformas
  for (const s of L.solids) { if (s.wall || s.x > cx + W || s.x + s.w < cx) continue; drawSolid(s, gp, cx); }
  const TP = tpal(L.biome);
  ctx.save(); ctx.lineWidth = 0.55; ctx.lineCap = 'round';
  for (const dc of L.decor) if (dc.x > cx - 4 && dc.x < cx + W + 4) {
    const sway = Math.sin(t * 1.5 + dc.x * 0.04) * dc.h * 0.22;
    ctx.strokeStyle = dc.c > 0.7 && b.grass ? b.grass : TP.moss[dc.c > 0.35 ? 2 : 1];
    ctx.beginPath(); ctx.moveTo(dc.x, dc.y + 0.5); ctx.quadraticCurveTo(dc.x - sway * 0.2, dc.y - dc.h * 0.6, dc.x + sway, dc.y - dc.h); ctx.stroke();
  }
  ctx.restore();
  for (const r of L.ramps) if (Math.max(r.x0, r.x1) > cx - 20 && Math.min(r.x0, r.x1) < cx + W + 20) drawRampPiece(r, L.biome);
  for (const st of L.stumps) if (st.x > cx - 30 && st.x < cx + W + 30) drawStumpPiece(st, L.biome);
  for (const th of L.thorns) if (th.x1 > cx && th.x0 < cx + W) drawThornPiece(th, L.biome);
  for (const v of L.vines) if (v.x > cx - 10 && v.x < cx + W + 10) drawVinePiece(v, L.biome, t);
  for (const c of L.chests) if (c.x > cx - 20 && c.x < cx + W + 20 && (!c.need || gateOpen(c.need))) drawChest(c, t);
  for (const d of L.dthorns) if (d.x > cx - 20 && d.x < cx + W + 20) drawDarkThorn(d, t);
  ctx.globalAlpha = 0.45; for (const s of L.shade.concat(G.dynShade)) rect(ctx, s.x, GY - 2, s.w, 32, '#1a100a'); ctx.globalAlpha = 1;
  // perigos de fundo
  for (const h of G.hazards) if (h.kind !== 'gas') (HZ[h.kind] || h).draw(h);
  // NPCs
  if (G.P && !G.P.hidden) drawContactShadow(G.P.x + 5, G.P.y + G.P.h, 10);
  if (G.boss) drawContactShadow(G.boss.x, G.boss.y, 22);
  for (const n of L.npcs) {
    if (n.hidden) continue;
    n.t += 1 / 60;
    const gy = groundY(n.x, n.y0 || 0);
    drawContactShadow(n.x, gy, 9);
    ctx.save(); ctx.translate(n.x, gy); ctx.scale(n.scale || 1, n.scale || 1);
    drawHuman(ctx, 0, 0, n.f, { kind: n.anim, t: n.t, ph: n.ph || 0 }, n.spec);
    ctx.restore();
    if (typeof drawJourneyNPCDetails === 'function') drawJourneyNPCDetails(n, gy);
  }
  // inimigos
  const eye = EYE[L.biome];
  for (const e of G.ents) if (e.hp > 0 && e.x > cx - 40 && e.x < cx + W + 40) drawEnemy(ctx, e, e.x + e.w / 2, e.y + e.h, e.t, eye);
  if (G.boss) drawBoss(G.boss);
  drawBossFx();
  drawMapinguariFx();
  // jogador
  if (G.P && !G.P.hidden) {
    if (!G.cavePassage) drawPlayer(G.P, t);
    else drawCavePassagePlayer(G.P, t);
  }
  drawCaveFront(L, t);
  // projéteis
  for (const p of G.projs) drawProj(p);
  for (const h of G.hazards) if (h.kind === 'gas') HZ.gas.draw(h);
  // água (na frente)
  for (const w of L.water) {
    if (w.x > cx + W || w.x + w.w < cx) continue;
    const water = ctx.createLinearGradient(0, w.y, 0, w.y + 42);
    water.addColorStop(0, '#9f8ca25c'); water.addColorStop(0.22, '#655577a8'); water.addColorStop(1, '#26243bd9');
    ctx.fillStyle = water; ctx.fillRect(w.x, w.y, w.w, H - w.y);
    ctx.save(); ctx.lineWidth = 0.55; ctx.lineCap = 'round';
    for (let x = Math.max(w.x, cx - 8); x < Math.min(w.x + w.w, cx + W + 8); x += 8) {
      const o = Math.sin(t * 1.6 + x * 0.13) * 2, yy = w.y + 1 + (Math.floor(x / 8) % 3) * 1.4;
      ctx.strokeStyle = '#e0d3d28a'; ctx.beginPath(); ctx.moveTo(x + o, yy); ctx.quadraticCurveTo(x + o + 3, yy - 0.7, x + o + 5.5, yy); ctx.stroke();
    }
    ctx.restore();
  }
  // capim alto (na frente)
  for (const g of L.grass) drawGrass(g, t, b);
  // partículas
  for (const p of G.parts) {
    if (p.mote) { ctx.globalAlpha = Math.min(1, p.life) * (0.4 + 0.6 * Math.abs(Math.sin(G.t * 3 + p.x))); rect(ctx, p.x, p.y, 1, 1, p.col); continue; }
    ctx.globalAlpha = Math.min(1, p.life / p.max * 1.5); rect(ctx, p.x, p.y, p.s, p.s, p.col);
  }
  ctx.globalAlpha = 1;
  for (const cn of L.canopies) if (cn.x + cn.w > cx - 10 && cn.x < cx + W + 10) drawCanopy(cn, L.biome, t);
  for (const o of L.hvines) if (o.x > cx - 30 && o.x < cx + W + 30) drawHangingVines(o, L.biome, t);
  if (G.debug) {
    // modo de depuração (tecla ` ou F2): sólidos em vermelho, espinhos em laranja, cipós em azul
    ctx.globalAlpha = 0.35;
    for (const s of L.solids) if (!s.wall) rect(ctx, s.x, s.y, s.w, Math.min(s.h, H - s.y + 4), s.t === 'p' ? '#ff6060' : '#ff0000');
    for (const th of L.thorns) rect(ctx, th.x0 + 2, th.y - 10, th.x1 - th.x0 - 4, 10, '#ff9a20');
    for (const v of L.vines) rect(ctx, v.x - 8, v.y0, 16, v.y1 - v.y0, '#4080ff');
    for (const d of L.dthorns) rect(ctx, d.x - 7, GY - 16, 14, 16, '#ff9a20');
    for (const z of interactables()) rect(ctx, z.x - INTERACT_R, z.y - 30, INTERACT_R * 2, 30, '#40a0ff');
    ctx.globalAlpha = 1;
    for (const r of L.ramps) line(ctx, r.x0, r.y0, r.x1, r.y1, '#ff0000');
    if (G.lastHB) { ctx.strokeStyle = '#ff0'; ctx.strokeRect(G.lastHB.x, G.lastHB.y, G.lastHB.w, G.lastHB.h); }
  }
  ctx.restore(); ctx.restore();
  // efeitos de tela
  if (L.biome === 'caatinga' && G.heat > 40) { ctx.globalAlpha = (G.heat - 40) / 60 * 0.22 * (G.heatMul > 1 ? 1.5 : 1); rect(ctx, 0, 0, W, H, '#ffe0a0'); ctx.globalAlpha = 1; }
  if (G.dark > 0) { ctx.globalAlpha = G.dark; rect(ctx, 0, 0, W, H, '#000'); ctx.globalAlpha = 1; }
  if (L.cave) drawCaveDark();
  if (G.flash > 0) { ctx.globalAlpha = Math.min(0.5, G.flash * 4); rect(ctx, 0, 0, W, H, G.flashCol); ctx.globalAlpha = 1; }
  if (G.rain > 0) for (let i = 0; i < 60 * G.rain; i++) { const x = (hash(i) * W + G.t * 40 * (1 + hash(i + 9))) % W, y = (hash(i + 3) * H + G.t * 260 * (1 + hash(i + 5))) % H; rect(ctx, x, y, 1, 4, '#9fc0d8'); }
}
function drawWorldAtmosphere(id, b, t) {
  const light = id === 'cerrado' ? '#ffc67a' : id === 'caatinga' ? '#fff0c8' : id === 'mata' ? '#c4e5df' : id === 'coracao' ? '#7cf0d0' : '#e4e8b1';
  const img = tcache('atmosphere-' + id, W, H, c => {
    const sun = c.createRadialGradient(W * 0.64, 75, 2, W * 0.64, 75, W * 0.58);
    sun.addColorStop(0, light + '28'); sun.addColorStop(0.6, light + '0b'); sun.addColorStop(1, light + '00');
    c.fillStyle = sun; c.fillRect(0, 0, W, H);
    const mist = c.createLinearGradient(0, H - 65, 0, H - 27);
    mist.addColorStop(0, b.mist + '00'); mist.addColorStop(0.65, b.mist + '20'); mist.addColorStop(1, b.mist + '00');
    c.fillStyle = mist; c.fillRect(0, H - 65, W, 38);
  });
  ctx.drawImage(img, Math.sin(t * 0.12) * 1.5 - 1, -DY);
}
function drawContactShadow(x, feet, radius) {
  const gy = groundY(x, feet - 2), height = gy - feet;
  if (height < -3 || height > 42) return;
  const k = 1 - Math.max(0, height) / 55;
  ctx.save(); ctx.translate(x, gy + 0.5); ctx.scale(1, 0.22);
  const g = ctx.createRadialGradient(0, 0, 0, 0, 0, radius);
  g.addColorStop(0, '#08090c70'); g.addColorStop(1, '#08090c00');
  ctx.globalAlpha = k; ctx.fillStyle = g; ctx.fillRect(-radius, -radius, radius * 2, radius * 2); ctx.restore();
}
function drawSolid(s, gp, cx) {
  const b = G.lvl.biome;
  if (s.kind === 'journeyBridge') return drawJourneyBridge(s);
  if (s.t === 'p' && !(s.move && s.move.canoe)) return drawPlatSolid(s, b);
  if (s.t === 'g' && s.block) return drawBlockSolid(s, b);
  if (s.t === 'g') return drawGroundSolid(s, b, cx);
  const x0 = Math.max(s.x, cx - 2), x1 = Math.min(s.x + s.w, cx + W + 2);
  if (s.t === 'p') {
    if (s.move && s.move.canoe) { drawCanoe(s); return; }
    rect(ctx, s.x, s.y, s.w, 4, gp.plat); rect(ctx, s.x, s.y, s.w, 1, gp.top); rect(ctx, s.x, s.y + 4, s.w, 1, '#0006');
    rect(ctx, s.x + 3, s.y + 4, 2, 4, gp.plat); rect(ctx, s.x + s.w - 5, s.y + 4, 2, 4, gp.plat);
    return;
  }
  const bot = Math.min(H + 10, s.y + s.h);
  rect(ctx, x0, s.y, x1 - x0, bot - s.y, gp.fill);
  rect(ctx, x0, s.y, x1 - x0, 2, gp.top);
  if (bot - s.y > 22) rect(ctx, x0, s.y + 18, x1 - x0, bot - s.y - 18, gp.dark);
  for (let x = Math.floor(x0 / 4) * 4; x < x1; x += 4) { const hv = hash(x + s.y * 7); if (hv > 0.55) rect(ctx, x, s.y + 4 + (hash(x + 3) * 12 | 0), 2, 1, gp.speck); }
  if (s.block) { rect(ctx, s.x, s.y, 1, s.h, '#0005'); rect(ctx, s.x + s.w - 1, s.y, 1, s.h, '#0005'); }
}
function drawCanoe(s) {
  rect(ctx, s.x, s.y, s.w, 4, '#6a4428'); rect(ctx, s.x + 2, s.y + 4, s.w - 4, 2, '#4a2e1a'); rect(ctx, s.x, s.y, s.w, 1, '#8a5c36');
  rect(ctx, s.x - 2, s.y - 1, 3, 2, '#6a4428'); rect(ctx, s.x + s.w - 1, s.y - 1, 3, 2, '#6a4428');
}
function drawShadeZone(s, b) {
  ctx.globalAlpha = 0.14; rect(ctx, s.x, 70, s.w, GY - 70, '#2a1c14'); ctx.globalAlpha = 1;
  const cx = s.x + s.w / 2;
  if (s.kind === 'tree') {
    const r = seeded(s.x | 0);
    line(ctx, cx, GY, cx - 2, 70, '#3a2a20', 3);
    branch(ctx, cx - 2, 72, -Math.PI / 2 - 0.6, 18, 3, '#3a2a20', r); branch(ctx, cx - 2, 72, -Math.PI / 2 + 0.6, 18, 3, '#3a2a20', r);
    ell(ctx, cx, 58, s.w / 2 + 4, 10, '#4a5a3a'); ell(ctx, cx - 4, 54, s.w / 3, 7, '#5a6a44');
  } else if (s.kind === 'rock') {
    rect(ctx, s.x - 6, 64, s.w + 12, 12, '#6a4a38'); rect(ctx, s.x - 6, 64, s.w + 12, 2, '#8a6448'); rect(ctx, s.x + s.w - 4, 76, 10, GY - 76, '#5a3e2e'); rect(ctx, s.x + s.w - 4, 76, 2, GY - 76, '#7a5a42');
  } else if (s.kind === 'awning') {
    rect(ctx, s.x - 4, 78, s.w + 8, 4, '#8a6a3a'); for (let i = 0; i < s.w + 8; i += 3) rect(ctx, s.x - 4 + i, 76, 2, 3, '#c8a46a');
    rect(ctx, s.x, 82, 2, GY - 82, '#5a3e2e'); rect(ctx, s.x + s.w - 2, 82, 2, GY - 82, '#5a3e2e');
  }
}
function drawGrass(g, t, b) {
  ctx.save(); ctx.lineCap = 'round'; ctx.lineWidth = 0.65;
  for (let x = g.x; x < g.x + g.w; x += 2.6) {
    const h = 8 + hash(x) * 12, sw = Math.sin(t * 1.8 + x * 0.12) * 2.2 + (G.boss && G.boss.rustle && Math.abs(G.boss.rustle - x) < 20 ? Math.sin(t * 25) * 3 : 0);
    ctx.strokeStyle = hash(x + 1) > 0.5 ? (b.grass || '#c8903a') : '#92703c';
    ctx.beginPath(); ctx.moveTo(x, GY + 0.5); ctx.quadraticCurveTo(x - sw * 0.3, GY - h * 0.6, x + sw, GY - h); ctx.stroke();
  }
  ctx.restore();
}
function drawEcho(E, t) {
  const seen = G.save.echoes.includes(E.id);
  // enquanto não foi lido: anel de luz girando no chão, fiapos subindo e a chama-espírito por cima
  if (!seen) {
    for (let i = 0; i < 28; i++) { const a = i / 28 * HPI * 2 + t * 0.6, front = Math.sin(a) > 0; ctx.globalAlpha = (i % 3 ? 0.35 : 0.7) * (front ? 1 : 0.5); rect(ctx, E.x + Math.round(Math.cos(a) * 14), E.y - 1 + Math.round(Math.sin(a) * 3), 1, 1, i % 3 ? '#7ab8e8' : '#e0f4ff'); }
    for (let i = 0; i < 5; i++) { const p = (t * 0.35 + i / 5) % 1; ctx.globalAlpha = (1 - p) * 0.7; rect(ctx, E.x + Math.round(Math.sin(p * 7 + i * 2) * 7), E.y - 2 - Math.round(p * 30), 1, 2, '#bfe4ff'); }
    ctx.globalAlpha = 1;
  }
  ECHO_ART[E.id] && ECHO_ART[E.id](E.x, E.y, t);
  if (!seen) drawSparkle(ctx, E.x, E.y - 36 + Math.round(Math.sin(t * 1.8) * 2), t, '#9fd8ff');
}
const ECHO_ART = {
  pegadas(x, y) { for (let i = 0; i < 5; i++) { rect(ctx, x - 16 + i * 8, y - 1 - (i % 2), 3, 1, '#0b0d14'); rect(ctx, x - 15 + i * 8, y - 2 - (i % 2), 1, 1, '#0b0d14'); } },
  machado(x, y) { axeStump(x, y); },
  lanterna(x, y) { rect(ctx, x - 3, y - 9, 6, 8, '#3a3028'); rect(ctx, x - 2, y - 8, 4, 5, '#5a6060'); rect(ctx, x - 1, y - 11, 2, 2, '#3a3028'); for (let i = 0; i < 6; i++) rect(ctx, x + 10 + i * 9, y - 1, 6, 1, '#140a0a'); },
  escritura(x, y) { rect(ctx, x - 5, y - 4, 10, 4, '#d8c8a0'); rect(ctx, x - 5, y - 4, 10, 1, '#efe0c0'); rect(ctx, x + 2, y - 3, 2, 2, '#a8302a'); rect(ctx, x - 3, y - 2, 4, 1, '#8a7a60'); },
  poco(x, y) { rect(ctx, x - 9, y - 7, 18, 7, '#7a6a5a'); rect(ctx, x - 7, y - 7, 14, 2, '#1a1410'); rect(ctx, x - 9, y - 8, 18, 1, '#9a8a78'); rect(ctx, x + 14, y - 14, 1, 14, '#4a3428'); rect(ctx, x + 12, y - 11, 5, 1, '#4a3428'); rect(ctx, x - 6, y - 10, 4, 2, '#c8a46a'); rect(ctx, x - 5, y - 10, 2, 1, '#7aa8c0'); },
  engenho() {},
};
function drawProp(p, t) {
  const gy = p.y != null ? p.y : groundY(p.x);
  if (p.kind.startsWith('journey')) return drawJourneyProp(p, t, gy);
  if (p.kind === 'hut') { rect(ctx, p.x - 18, gy - 14, 36, 14, '#5a3e24'); for (let i = 0; i < 22; i++) rect(ctx, p.x - 22 + i, gy - 14 - i * 0.7, 44 - i * 2, 1, i % 3 ? '#8a6a3a' : '#a8844a'); rect(ctx, p.x - 3, gy - 9, 6, 9, '#1a100a'); }
  if (p.kind === 'malocas') { for (let k = 0; k < 2; k++) { const x = p.x + k * 50; for (let i = 0; i < 18; i++) ell(ctx, x, gy - i, 22 - i * 0.6 | 0, 1, i % 3 ? '#7a5a2e' : '#9a7a40'); rect(ctx, x - 3, gy - 7, 6, 7, '#1a100a'); } }
  if (p.kind === 'stilts') { for (let i = 0; i < 4; i++) rect(ctx, p.x - 16 + i * 10, gy - 20, 2, 20, '#4a3020'); rect(ctx, p.x - 20, gy - 22, 40, 3, '#6a4428'); for (let i = 0; i < 16; i++) rect(ctx, p.x - 22 + i, gy - 22 - i * 0.6 - 1, 44 - i * 2, 1, i % 2 ? '#a8844a' : '#8a6a3a'); }
  if (p.kind === 'cross') { rect(ctx, p.x, gy - 14, 2, 14, '#4a3428'); rect(ctx, p.x - 3, gy - 11, 8, 2, '#4a3428'); }
  if (p.kind === 'skull') { rect(ctx, p.x - 3, gy - 3, 6, 3, '#efe8dc'); rect(ctx, p.x - 6, gy - 5, 3, 1, '#efe8dc'); rect(ctx, p.x + 3, gy - 5, 3, 1, '#efe8dc'); rect(ctx, p.x - 1, gy - 2, 1, 1, '#2a2018'); }
  if (p.kind === 'ruin') { rect(ctx, p.x, gy - p.h, p.w, p.h, '#2e4448'); rect(ctx, p.x, gy - p.h, p.w, 2, '#4a6466'); if (p.arch) { ell(ctx, p.x + p.w / 2, gy - p.h * 0.45, p.w * 0.3 | 0, p.h * 0.25 | 0, '#16262a'); rect(ctx, p.x + p.w * 0.2, gy - p.h * 0.45, p.w * 0.6, p.h * 0.45, '#16262a'); } for (let i = 0; i < 4; i++) rect(ctx, p.x + hash(p.x + i) * p.w, gy - hash(p.x + i * 3) * p.h, 1, 6, '#3d6a4a'); }
  if (p.kind === 'engenho') drawEngenho(p.x, gy, t);
  if (p.kind === 'heart') drawHeart(p.x, gy, t, p.green);
  if (p.kind === 'npcfire') drawFire(ctx, p.x, gy, t, true);
}
function drawEngenho(x, gy, t) {
  rect(ctx, x - 50, gy - 46, 100, 46, '#2a3a3c'); rect(ctx, x - 56, gy - 50, 112, 5, '#3d5560');
  for (let i = 0; i < 4; i++) { rect(ctx, x - 42 + i * 24, gy - 36, 10, 14, '#0e1618'); }
  rect(ctx, x - 6, gy - 22, 12, 22, '#0e1618');
  rect(ctx, x + 30, gy - 80, 10, 34, '#3a3434'); rect(ctx, x + 28, gy - 82, 14, 3, '#4a4444');
  for (let i = 0; i < 6; i++) rect(ctx, x - 50 + hash(i + 40) * 100, gy - 50 + hash(i) * 40, 1, 8 + hash(i + 2) * 10, '#3d6a4a');
  ell(ctx, x - 70, gy - 6, 12, 6, '#4a4040'); rect(ctx, x - 72, gy - 14, 4, 8, '#3a3030');
}
function drawProj(p) {
  const f = Math.sign(p.vx) || 1;
  if (p.kind === 'dart') { rect(ctx, p.x - 3, p.y, 6, 1, '#d8c8a0'); rect(ctx, p.x + (f > 0 ? 2 : -3), p.y, 1, 1, p.poison ? '#8fe37a' : '#fff'); rect(ctx, p.x - f * 3, p.y - 1, 1, 3, '#c8402e'); }
  else if (p.kind === 'orb') { softGlow(ctx, p.x, p.y, 10, 10, '#8a7ab0', 0.5); rect(ctx, p.x - 2, p.y - 2, 4, 4, '#c8b8f0'); rect(ctx, p.x - 1, p.y - 1, 2, 2, '#ffe066'); }
  else if (p.kind === 'arrow' || p.kind === 'javelin') { const L2 = p.kind === 'arrow' ? 9 : 13, a = Math.atan2(p.vy, p.vx), cx = Math.cos(a), cy = Math.sin(a); for (let i = 0; i < L2; i++) rect(ctx, p.x - cx * i, p.y - cy * i, 1, 1, p.kind === 'arrow' ? '#c8a46a' : '#8a6a3a'); rect(ctx, p.x - 1 + cx, p.y - 1 + cy, 2, 2, '#d8d8d0'); rect(ctx, p.x - cx * (L2 - 1), p.y - cy * (L2 - 1) - 1, 1, 2, '#efe8dc'); }
  else if (p.kind === 'drop') { rect(ctx, p.x - 2, p.y - 2, 4, 4, '#9fd0e0'); rect(ctx, p.x - 1, p.y - 2, 1, 1, '#ffffff'); rect(ctx, p.x - 3 - f * 2, p.y, 2, 1, '#9fd0e0'); }
  else if (p.kind === 'seed') { rect(ctx, p.x - 2, p.y - 1, 4, 3, '#a8844a'); rect(ctx, p.x - 1, p.y - 3, 1, 2, '#8fe37a'); rect(ctx, p.x - f * 4, p.y, 2, 1, '#6fd36a'); }
  else if (p.kind === 'fire') { rect(ctx, p.x - 4, p.y, 8, 1, '#c8a46a'); rect(ctx, p.x + f * 3, p.y - 1, 3, 3, '#ffd27a'); rect(ctx, p.x + f * 4, p.y, 1, 1, '#fff'); }
  else if (p.kind === 'spear') { rect(ctx, p.x - 9, p.y, 18, 1, '#8a6a3a'); rect(ctx, p.x + (f > 0 ? 8 : -11), p.y - 1, 3, 3, '#d8d8d0'); }
  else if (p.kind === 'crescentp') { for (let i = 0; i <= 12; i++) { const a = -1.2 + i / 12 * 2.4, th = Math.sin(i / 12 * HPI) * 4; for (let k = 0; k < th; k++) rect(ctx, p.x + f * Math.cos(a) * (10 - k), p.y + Math.sin(a) * 11, 2, 1, k < 1 ? '#ffd0c0' : '#c8202a'); } }
  else if (p.kind === 'blob') { rect(ctx, p.x - 2, p.y - 2, 5, 5, '#0d0a10'); rect(ctx, p.x - 1, p.y - 1, 2, 2, EYE[G.lvl.biome]); }
  else if (p.kind === 'rock') { ell(ctx, p.x, p.y, 6, 5, '#6a5a4a'); rect(ctx, p.x - 3, p.y - 3, 3, 2, '#8a7a68'); }
  else if (p.kind === 'pebble') rect(ctx, p.x - 2, p.y - 2, 4, 4, '#6a5a4a');
  else if (p.kind === 'thorn') { rect(ctx, p.x - 3, p.y, 6, 1, '#6a4a2a'); rect(ctx, p.x + f * 2, p.y - 1, 2, 3, '#c8a46a'); }
  else if (p.kind === 'bird') { const w = Math.sin(G.t * 20) > 0; rect(ctx, p.x - 3, p.y - 1, 7, 3, '#efe8dc'); rect(ctx, p.x + f * 4, p.y, 3, 1, '#2a2018'); rect(ctx, p.x - 6, p.y - (w ? 4 : -1), 5, 2, '#d8d0c0'); rect(ctx, p.x + 1, p.y - (w ? 4 : -1), 5, 2, '#d8d0c0'); }
  else if (p.kind === 'drain') { ctx.globalAlpha = 0.85; rect(ctx, p.x - 4, p.y - 2, 8, 4, '#3a1a10'); rect(ctx, p.x - 2, p.y - 1, 4, 2, '#c8402e'); ctx.globalAlpha = 1; }
  else rect(ctx, p.x - p.w / 2, p.y - p.h / 2, p.w, p.h, '#fff');
}
function drawPlayer(P, t) {
  if (P.inv > 0 && P.state !== 'dash' && Math.floor(t * 20) % 2 === 0 && P.state !== 'dead') return;
  const s = P.state, F = FORMS[P.form] || FORMS.espirito;
  let a;
  const wpn = (SPEC[P.form] || {}).weapon;
  if (s === 'dash') a = { kind: 'dash', p: P.stT / F.dash.dur };
  else if (s === 'attack' && P.def.type === 'shot') a = { kind: 'shot', p: P.stT / P.def.dur, shot: P.def.kind, at: P.def.at / P.def.dur };
  else if (s === 'attack') a = { kind: 'attack', p: P.stT / P.def.dur, style: wpn === 'bow' ? ['over', 'sweep', 'thrust'][P.combo] : wpn === 'spear' ? 'thrust' : wpn === 'staff' || wpn === 'paddle' ? 'over' : wpn === 'blowgun' ? 'jab' : 'claw' };
  else if (s === 'special') a = { kind: 'special', p: P.stT / P.def.dur, shot: P.def.type, at: { burst: 0.16, firearrow: 0.56, throw: 0.44, splash: 0.44, roots: 0.5 }[P.def.type] };
  else if (s === 'heal') a = { kind: 'heal', t };
  else if (s === 'hurt') a = { kind: 'hurt', p: P.stT / 0.28 };
  else if (s === 'dead') a = { kind: 'dead', p: (P.deadT || 0) / 1.2 };
  else if (s === 'climb') a = { kind: 'climb', t, moving: Math.abs(P.vy) > 5 };
  else if (!P.onG) a = { kind: P.vy < 0 ? 'jump' : 'fall' };
  else if (Math.abs(P.vx) > 12) a = { kind: Math.abs(P.vx) > 55 ? 'run' : 'walk', ph: P.ph };
  else a = { kind: P.kneel ? 'kneel' : 'idle', t };
  const spec = playerSpec(P.form);
  const alpha = P.fadeA != null ? P.fadeA : undefined;
  if (s === 'dash') {
    for (let i = 3; i > 0; i--) drawHuman(ctx, P.x + 5 - P.f * i * 7, P.y + P.h, P.f, a, spec, false, (alpha == null ? 1 : alpha) * (0.24 - i * 0.05));
  }
  if (P.form === 'espirito' && !G.flags.noGlow) softGlow(ctx, P.x + 5, P.y + P.h - 11, 21, 27, '#8a7ab0', 0.25 + Math.sin(t * 3) * 0.04);
  drawHuman(ctx, P.x + 5, P.y + P.h, P.f, a, spec, P.state === 'hurt' && P.stT < 0.08, alpha);
  if (P.stun > 0) for (let i = 0; i < 3; i++) rect(ctx, P.x + 5 + Math.cos(t * 8 + i * 2) * 6, P.y - 4 + Math.sin(t * 8 + i * 2) * 2, 1, 1, '#c8f060');
}

// Coração da mata: semente viva num berço de raízes (vermelha enquanto corrompida, verde quando devolvida)
function drawHeart(x, gy, t, green) {
  const k = (Math.sin(t * 2) + 1) / 2, cy = gy - 42;
  const glow = green ? '#7af0c0' : '#e0904a', core = green ? ['#1e6a4a', '#3aa070', '#9af0c0'] : ['#5a2010', '#a04a20', '#f0b060'];
  softGlow(ctx, x, cy, 59 + k * 4, 54 + k * 4, glow, 0.25 + k * 0.12);
  // raízes: saem do chão, abraçam a semente e se fecham por cima
  const roots = [[-34, 0, -24, -22, -10, -40], [-20, 0, -16, -26, -6, -50], [34, 0, 24, -22, 10, -40], [20, 0, 16, -26, 6, -50], [-6, 0, -12, -18, -12, -30], [6, 0, 12, -18, 12, -30]];
  for (const [a, b, c2, d, e, f2] of roots) { const pts = curve(x + a, gy + b, x + c2, gy + d, x + e, gy + f2, 22); strokePath(ctx, pts, 3, '#3a2a40', '#0a0610'); pts.forEach(([px, py], i) => { if (i % 4 === 2) rect(ctx, px, py - 1, 1, 1, green ? '#5ae0b0' : '#c8803a'); }); }
  ell(ctx, x, cy + 1, 11, 13, '#0a0610'); ell(ctx, x, cy, 10, 12, core[0]); ell(ctx, x - 1, cy - 1, 7, 9, core[1]); ell(ctx, x - 2, cy - 3, 3 + k * 1.5 | 0, 4 + k * 1.5 | 0, core[2]); rect(ctx, x - 4, cy - 7, 2, 2, '#fff8e0');
  for (let i = 0; i < 3; i++) { const a = t * 1.5 + i * 2.1; rect(ctx, x + Math.cos(a) * 16, cy + Math.sin(a) * 12, 1, 1, glow); }
}
// raízes que brotam do chão (especial das sementes e dissolução): rachadura, depois raízes curvas com folhas
function drawRootBurst(h) {
  const gy = h.y + h.h, r = seeded(Math.round(h.x));
  if (h.t < 0.22) { for (let i = 0; i < h.w; i += 2) rect(ctx, h.x + i, gy - 1 - (i % 4 === 0 ? 1 : 0), 1, 1, i % 4 ? '#2a1a10' : '#8fe37a'); return; }
  const k = Math.min(1, (h.t - 0.22) / 0.1) * Math.min(1, h.life / 0.25);
  for (let i = 0; i < 4; i++) {
    const bx = h.x + 3 + i * (h.w - 6) / 3, lean = (r() - 0.5) * 10, hh = h.h * k * (0.6 + r() * 0.4);
    const pts = curve(bx, gy, bx + lean * 0.3, gy - hh * 0.6, bx + lean, gy - hh, 12);
    strokePath(ctx, pts, 2, '#5a3a22', '#1a0e08');
    pts.forEach(([px, py], j) => { if (j % 3 === 1) rect(ctx, px + 1, py, 1, 1, '#6aa04a'); });
    const [tx, ty] = pts[pts.length - 1]; rect(ctx, tx - 2, ty - 1, 3, 2, '#4a8a3a'); rect(ctx, tx, ty - 2, 3, 2, '#8fe37a');
  }
  for (let i = 0; i < h.w; i += 3) rect(ctx, h.x + i, gy - 1, 2, 1, '#3a2a1a');
}
